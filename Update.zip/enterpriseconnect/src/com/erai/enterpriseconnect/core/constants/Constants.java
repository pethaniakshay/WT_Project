package com.erai.enterpriseconnect.core.constants;

import java.util.HashMap;

public final class Constants {
  public static final String ROLE_ADMIN = "ROLE_ADMIN";
  public static final long ROLE_ADMIN_ID = 1;
  public static final long ROLE_USER_ID = 2;
  public static final String APP_DATE_FORMAT = "yyyy/MM/dd";
  public static final String INV_SUFFIX = "I";
  public static final String COUNTRY_INDIA = "INDIA";
  public static final String COUNTRY_JAPAN = "JAPAN";
  public static final String MONTH_ALL = "ALL";
  public final static HashMap localMap = new HashMap();
  static {
    localMap.put("en", "English");
    localMap.put("jp", "Japanese");
  }
  // SYMBOLS
  public static final String PARAM_SEP = "&&";
  public static final String EQUAL = "=";
  public static final String PATH_SEPERATOR = "/";
  public static final String QUESTION_MARK = "?";
  public static final String COLON = ":";

  // URL
  public static final String DASHBOARD = "/dashboard";
  public static final String LOGIN = "login";
  public static final String LOGOUT = "/login?logout";

  public static final String REFERER_HEADER = "Referer";
  public static final String LANGUAGE = "language";
  public static final String JP_LOCAL = "jp";
  public static final String AES_ALGORITHM = "AES";
  public static final String UTF_8 = "utf-8";
  public static final String USERNAME = "username";
  public static final String TIMEZONE = "timezone";
  public static final String ERROR = "error";
}
