package com.erai.enterpriseconnect.core.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import org.slf4j.Logger;

public class LoggerInterceptor extends HandlerInterceptorAdapter{
  static Logger logger = LoggerFactory.getLogger(LoggerInterceptor.class);

  
  @Override
  public boolean preHandle(HttpServletRequest request,
      HttpServletResponse response, Object handler) throws Exception {
    MDC.put("user",  SecurityContextHolder.getContext().getAuthentication().getName());
    return super.preHandle(request, response, handler);
  }
}
