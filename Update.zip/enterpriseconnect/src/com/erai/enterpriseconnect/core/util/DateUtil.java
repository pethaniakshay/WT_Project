package com.erai.enterpriseconnect.core.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.erai.enterpriseconnect.security.FeedSuccessHandler;

@Service
public class DateUtil {
  private static final Logger logger = LoggerFactory
      .getLogger(DateUtil.class);
  
  public static Date getSqlDate(String date){
    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
    Date parsed = null ;
    try {
      parsed = format.parse(date);
    } catch (ParseException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return new java.sql.Date(parsed.getTime());
    
  }
  
  public static boolean isLeapYear(int year) {
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.YEAR, year);
    return cal.getActualMaximum(Calendar.DAY_OF_YEAR) > 365;
  }
  
  public static Date getDate(String date){
    SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
    Date parsed = null ;
    try {
      parsed = format.parse(date);
    } catch (ParseException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return parsed;
    
  }
  
  public static Date getLocaleTime(String id){
    int gmtOffset = TimeZone.getTimeZone(id).getRawOffset();
    long now = System.currentTimeMillis() + gmtOffset;
    return new Date(now);
  }

  public static List<String> getTimeZoneList(){
    String[] ids = TimeZone.getAvailableIDs();
    return Arrays.asList(ids);  
  }
}
