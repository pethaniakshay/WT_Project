package com.erai.enterpriseconnect.core.util;

import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.erai.enterpriseconnect.core.constants.Constants;

@Service
public class RequestUtil {

  public static String getBaseUrl(HttpServletRequest request){
    StringBuffer url = request.getRequestURL();
    String uri = request.getRequestURI();
    String ctx = request.getContextPath();
    String base = url.substring(0, url.length() - uri.length() + ctx.length()) + "/";
    return base;
  }
  /**
   * Get value of Request Parameter
   * @param url
   * @param param
   * @return
   */
  public static String getParamValue(String url ,String param){
    if( ! url.contains(param)){
      return null;
    }
    String[] val = url.split(param)[1].split(Constants.EQUAL);
     if(val.length <2) return null;
    return val[1];
  }
}
