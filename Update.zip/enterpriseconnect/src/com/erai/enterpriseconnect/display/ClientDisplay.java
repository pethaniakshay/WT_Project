package com.erai.enterpriseconnect.display;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterTax;

public class ClientDisplay implements Serializable {
  
  public long getClientProfileId() {
    return clientProfileId;
  }
  public void setClientProfileId(long clientProfileId) {
    this.clientProfileId = clientProfileId;
  }
  public String getCompanyName() {
    return companyName;
  }
  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }
  private long clientProfileId;
  private String companyName;
  public String getClientType() {
    return clientType;
  }
  public void setClientType(String clientType) {
    this.clientType = clientType;
  }
  public String getSalesInCharge() {
    return salesInCharge;
  }
  public void setSalesInCharge(String salesInCharge) {
    this.salesInCharge = salesInCharge;
  }
  private String clientType;
  private String salesInCharge;
  private String zipCode;
  private String telephoneNo;
  private String address;
  private List<String> estList = new ArrayList<String>();
  
  public List<String> getEstList() {
    return estList;
  }
  public void setEstList(List<String> estList) {
    this.estList = estList;
  }
  public String getZipCode() {
    return zipCode;
  }
  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }
  public String getTelephoneNo() {
    return telephoneNo;
  }
  public void setTelephoneNo(String telephoneNo) {
    this.telephoneNo = telephoneNo;
  }
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }
}
