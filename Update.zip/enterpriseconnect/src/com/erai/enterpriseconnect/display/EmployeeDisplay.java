/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * Created on : 22-8-2017
 * Author     : Akshay pethani
 * Version    : 1.0
 */

package com.erai.enterpriseconnect.display;

import java.io.Serializable;

/**
 * @author Akshay Pethani
 */
public class EmployeeDisplay implements Serializable{
  private long empId;
  private String empName;

  public long getEmpId(){
    return empId;
  }

  public void setEmpId(long empId){
    this.empId = empId;
  }
  public String getEmpName(){
    return empName;
  }

  public void setEmpName(String empName){
    this.empName = empName;
  }
}