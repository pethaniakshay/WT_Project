package com.erai.enterpriseconnect.display;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterPaymentTerms;
import com.erai.enterpriseconnect.model.MasterTax;
import com.erai.enterpriseconnect.model.Project;
import com.erai.enterpriseconnect.model.ProjectVolume;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.model.WorkData;

public class WorkDataDisplay implements Serializable {
 
  private String particular;
  private int noOfResources;
  private String tax;
  private String managementCost;
  private ProjectVolume projectVolume;
  private Boolean isWorkData;
  private int displayOrder;
  private String rate;
  public String getParticular() {
    return particular;
  }
  public void setParticular(String particular) {
    this.particular = particular;
  }
  public int getNoOfResources() {
    return noOfResources;
  }
  public void setNoOfResources(int noOfResources) {
    this.noOfResources = noOfResources;
  }
  public String getTax() {
    return tax;
  }
  public void setTax(String tax) {
    this.tax = tax;
  }
  public String getManagementCost() {
    return managementCost;
  }
  public void setManagementCost(String managementCost) {
    this.managementCost = managementCost;
  }
  public ProjectVolume getProjectVolume() {
    return projectVolume;
  }
  public void setProjectVolume(ProjectVolume projectVolume) {
    this.projectVolume = projectVolume;
  }
  public Boolean getIsWorkData() {
    return isWorkData;
  }
  public void setIsWorkData(Boolean isWorkData) {
    this.isWorkData = isWorkData;
  }
  public int getDisplayOrder() {
    return displayOrder;
  }
  public void setDisplayOrder(int displayOrder) {
    this.displayOrder = displayOrder;
  }
  public String getRate() {
    return rate;
  }
  public void setRate(String rate) {
    this.rate = rate;
  }

  
}
