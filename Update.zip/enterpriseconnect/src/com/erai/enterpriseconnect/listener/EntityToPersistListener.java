package com.erai.enterpriseconnect.listener;

import java.beans.PropertyDescriptor;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.PropertyAccessorUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.erai.enterpriseconnect.core.util.DateUtil;
import com.erai.enterpriseconnect.core.util.EncrptBean;
import com.erai.enterpriseconnect.model.Auditable;
import com.erai.enterpriseconnect.model.BasicModel;
import com.erai.enterpriseconnect.model.Encryptable;

@Component
public class EntityToPersistListener {

  static private HttpSession httpSession;

  private static final Logger logger = LoggerFactory
      .getLogger(EntityToPersistListener.class);

  @Autowired(required = true)
  @Qualifier("httpSession")
  public void setHttpSession(HttpSession httpSession) {
    this.httpSession = httpSession;
  }

  @PrePersist
  @PreUpdate
  public void methodExecuteBeforeSave(final Object reference) {
    if (reference instanceof Auditable) {
      Auditable au = (Auditable) reference;
      au.setCreated_user((String) httpSession.getAttribute("username"));
      au.setUpdated_user((String) httpSession.getAttribute("username"));
      au.setCreated_date(DateUtil.getLocaleTime((String) httpSession.getAttribute("timezone")));
      au.setUpdated_date(DateUtil.getLocaleTime((String) httpSession.getAttribute("timezone")));
    }
    if (reference instanceof Encryptable) {
      Encryptable ec = (Encryptable) reference;
      List<String> enFieldList = ec.getEncryptFieldsInfo();
      try {
        for(String field : enFieldList){
          PropertyDescriptor pd = new PropertyDescriptor(field, reference.getClass());
          Object value = pd.getReadMethod().invoke(reference);
          pd.getWriteMethod().invoke(reference, EncrptBean.encrypt((String)value));
        }
      } catch (Exception e) {
        // TODO Auto-generated catch block
        logger.error("error", e);
        e.printStackTrace();
      }
    }
  }
  @PostLoad
  public void methodExecutePostLoad(final Object reference) {
    if (reference instanceof Encryptable) {
      Encryptable ec = (Encryptable) reference;
      List<String> enFieldList = ec.getEncryptFieldsInfo();
      try {
        for(String field : enFieldList){
          PropertyDescriptor pd = new PropertyDescriptor(field, reference.getClass());
          Object value = pd.getReadMethod().invoke(reference);
          pd.getWriteMethod().invoke(reference, EncrptBean.decrypt((String)value));
        }
      } catch (Exception e) {
        // TODO Auto-generated catch block
        logger.error("error", e);
        e.printStackTrace();
      }
    }
  }
}
