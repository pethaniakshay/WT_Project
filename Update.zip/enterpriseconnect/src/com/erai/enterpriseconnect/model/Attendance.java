/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * Created on : 14-8-2017
 * Author     : Akshay pethani
 * Version    : 1.0
 */

package com.erai.enterpriseconnect.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * Domain class for Entity Resources
 * @author Akshay Pethani
 */
@Entity
@Table(name = "attendance")
public class Attendance {
  private Long attendanceId;
  private Employee employee;
  private Date inTime;
  private Date outTime;
  private Date attDate;
  private String day;
  private String workHour;
  private String remarks;
  private String createdUser;
  private String updatedUser;
  private Date createdDate;
  private Date updatedDate;
  private Country country;
  private String formattedAttDate;
  private String formattedOutTime;
  private String formattedInTime;
  private int serialNumber;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "ATTENDANCE_ID")
  public Long getAttendanceId() {
    return attendanceId;
  }

  public void setAttendanceId(Long attendanceId) {
    this.attendanceId = attendanceId;
  }

  @OneToOne
  @JoinColumn(name = "EMP_ID", referencedColumnName = "EMP_ID")
  public Employee getEmployee() {
    return employee;
  }

  public void setEmployee(Employee employee) {
    this.employee = employee;
  }

  @Column(name = "IN_TIME")
  public Date getInTime() {
    return inTime;
  }

  public void setInTime(Date inTime) {
    this.inTime = inTime;
  }

  @Column(name = "OUT_TIME")
  public Date getOutTime() {
    return outTime;
  }

  public void setOutTime(Date outTime) {
    this.outTime = outTime;
  }

  @Column(name = "ATT_DATE")
  public Date getAttDate() {
    return attDate;
  }

  public void setAttDate(Date attDate) {
    this.attDate = attDate;
  }

  @Column(name = "ATT_DAY")
  public String getDay() {
    return day;
  }

  public void setDay(String day) {
    this.day = day;
  }

  @Column(name = "WORKHOUR")
  public String getWorkHour() {
    return workHour;
  }

  public void setWorkHour(String workHour) {
    this.workHour = workHour;
  }

  @Column(name = "REMARKS")
  public String getRemarks() {
    return remarks;
  }

  public void setRemarks(String remarks) {
    this.remarks = remarks;
  }

  @Column(name = "CREATED_USER")
  public String getCreatedUser() {
    return createdUser;
  }

  public void setCreatedUser(String createdUser) {
    this.createdUser = createdUser;
  }

  @Column(name = "UPDATED_USER")
  public String getUpdatedUser() {
    return updatedUser;
  }

  public void setUpdatedUser(String updatedUser) {
    this.updatedUser = updatedUser;
  }

  @Column(name = "CREATED_DATE")
  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  @Column(name = "UPDATED_DATE")
  public Date getUpdatedDate() {
    return updatedDate;
  }

  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }

  @OneToOne
  @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID")
  public Country getCountry() {
    return country;
  }

  public void setCountry(Country country) {
    this.country = country;
  }

  @Transient
  public String getFormattedAttDate() {
    return formattedAttDate;
  }

  @Transient
  public void setFormattedAttDate(String formattedAttDate) {
    this.formattedAttDate = formattedAttDate;
  }

  @Transient
  public String getFormattedInTime() {
    return formattedInTime;
  }

  @Transient
  public void setFormattedInTime(String formattedInTime) {
    this.formattedInTime = formattedInTime;
  }

  @Transient
  public String getFormattedOutTime() {
    return formattedOutTime;
  }

  @Transient
  public void setFormattedOutTime(String formattedOutTime) {
    this.formattedOutTime = formattedOutTime;
  }

  @Transient
  public int getSerialNumber() {
    return serialNumber;
  }

  @Transient
  public void setserialNumber(int serialNumber) {
    this.serialNumber = serialNumber;
  }
}