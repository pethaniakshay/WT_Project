/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.*;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Domain class for Entity User
 * 
 * @author anand
 *
 */

public class BasicModel {
	
    private String created_user;
    private Date created_date;
    private String updated_user;
    private Date updated_date;
	
	
  	
  	 
    

     
}
