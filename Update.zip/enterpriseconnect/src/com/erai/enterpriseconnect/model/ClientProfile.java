package com.erai.enterpriseconnect.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "client_profile")
public class ClientProfile implements Serializable{
  private Long clientProfileId;
  private String website;
  private String companyName;
  private String zipCode;
  private String telephoneNo;
  private String address;
  private String email;
  private Country country;
  private BankProfile bankProfile; 
  private MasterClientStatus masterClientStatus; 
  private MasterClientType masterClientype;
  private UserProfile userProfile;
  private Set<Project> projects = new HashSet<Project>(0);

  @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
   @Column(name = "CLIENT_PROFILE_ID")
  public Long getClientProfileId() {
    return clientProfileId;
  }

  public void setClientProfileId(Long clientProfileId) {
    this.clientProfileId = clientProfileId;
  }
  @Column(name = "CLIENT_WEBSITE")
  public String getWebsite() {
    return website;
  }

  public void setWebsite(String website) {
    this.website = website;
  }
  
  @Column(name = "COMPANY_NAME")
  public String getCompanyName() {
    return companyName;
  }

  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  @Column(name = "ZIP_CODE")
  public String getZipCode() {
    return zipCode;
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  @Column(name = "TELEPHONE_NO")
  public String getTelephoneNo() {
    return telephoneNo;
  }

  public void setTelephoneNo(String telephoneNo) {
    this.telephoneNo = telephoneNo;
  }

  @Column(name = "ADDRESS")
  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  @Column(name = "EMAIL")
  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }
   @OneToOne
    @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID")
    public Country getCountry() {
      return country;
    }

   public void setCountry(Country country) {
      this.country = country;
    }
    
   @ManyToOne(fetch = FetchType.EAGER)
   @JoinColumn(name = "BANK_ID", nullable = false)
    public BankProfile getBankProfile() {
      return bankProfile;
    }

    public void setBankProfile(BankProfile bankProfile) {
      this.bankProfile = bankProfile;
    }
    
    @OneToOne
    @JoinColumn(name = "STATUS_ID", referencedColumnName = "STATUS_ID")
    public MasterClientStatus getMasterClientStatus() {
      return masterClientStatus;
    }

    public void setMasterClientStatus(MasterClientStatus masterClientStatus) {
      this.masterClientStatus = masterClientStatus;
    }
    
    @OneToOne
    @JoinColumn(name = "CLIENT_TYPE_ID", referencedColumnName = "TYPE_ID")
    public MasterClientType getMasterClientype() {
      return masterClientype;
    }

    public void setMasterClientype(MasterClientType masterClientype) {
      this.masterClientype = masterClientype;
    }
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "USER_PROFILE_ID", nullable = false)
    public UserProfile getUserProfile() {
     return userProfile;
   }

   public void setUserProfile(UserProfile userProfile) {
     this.userProfile = userProfile;
   }
   
   @OneToMany(fetch = FetchType.EAGER, mappedBy = "clientProfile")
   public Set<Project> getProjects() {
     return projects;
   }

   public void setProjects(Set<Project> projects) {
     this.projects = projects;
   }

}
