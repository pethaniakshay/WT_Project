package com.erai.enterpriseconnect.model;

import java.util.Date;
import java.util.List;


public interface Encryptable {

  public List<String> getEncryptFieldsInfo();

}
