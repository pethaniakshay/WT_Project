/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;


import javax.persistence.*;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Cascade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;

import com.erai.enterpriseconnect.core.util.EncrptBean;
import com.erai.enterpriseconnect.listener.EntityToPersistListener;
import com.erai.enterpriseconnect.web.BillingsController;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Domain class for Entity Estimation
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "estimation")
@EntityListeners(EntityToPersistListener.class)
public class Estimation implements Auditable,Encryptable{
  
  private final Logger logger = LoggerFactory
      .getLogger(Estimation.class);
    private String id;
    private Date dateOfIssue;
    private Country country;
    private String estimationAmount;
    private Date estimationValidity;
    private ClientProfile clientProfile;
    private UserProfile userProfile;
    private MasterPaymentTerms masterPaymentTerms;
    private Project project;
    private String others;
    private String formattedDate;
    private String invoices ;

    private String poNumber;
    private String created_user;
    private Date created_date;
    private String updated_user;
    private Date updated_date;
    private Set<WorkData> workData = new HashSet<WorkData>(0);
    private String balance ;

    @Id
    @Column(name="ESTIMATION_ID")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    @Column(name="DATE_OF_ISSUE")
    @DateTimeFormat(pattern="yyyy/MM/dd")
    public Date getDateOfIssue() {
        return dateOfIssue;
    }

    public void setDateOfIssue(Date dateOfIssue) {
        this.dateOfIssue = dateOfIssue;
    }

    @Column(name="ESTIMATION_AMOUNT")
    public String getEstimationAmount() {
     return estimationAmount;
    }

    public void setEstimationAmount(String estimationAmount) {
      this.estimationAmount = estimationAmount;
    }

    @Column(name="ESTIMATION_VALIDITY")
    @DateTimeFormat(pattern="yyyy/MM/dd")
    public Date getEstimationValidity() {
      return estimationValidity;
    }

    public void setEstimationValidity(Date estimationValidity) {
      this.estimationValidity = estimationValidity;
    }

    @OneToOne
    @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID")
    public Country getCountry() {
      return country;
    }

    public void setCountry(Country country) {
      this.country = country;
    }
    
    @OneToOne
    @JoinColumn(name = "CLIENT_PROFILE_ID", referencedColumnName = "CLIENT_PROFILE_ID")
    public ClientProfile getClientProfile() {
      return clientProfile;
    }

    public void setClientProfile(ClientProfile clientProfile) {
      this.clientProfile = clientProfile;
    }
    
    @OneToMany( fetch = FetchType.EAGER, cascade = {CascadeType.ALL},mappedBy = "estimation")
    public Set<WorkData> getWorkData() {
      return this.workData;
    }

    public void setWorkData(Set<WorkData> workData) {
      this.workData = workData;
    }
    
    @OneToOne
    @JoinColumn(name = "USER_PROFILE_ID", referencedColumnName = "USER_PROFILE_ID")
    public UserProfile getUserProfile() {
      return userProfile;
    }

    public void setUserProfile(UserProfile userProfile) {
      this.userProfile = userProfile;
    }
    
    @OneToOne
    @JoinColumn(name = "PAYMENT_ID", referencedColumnName = "PAYMENT_ID")
    public MasterPaymentTerms getMasterPaymentTerms() {
      return masterPaymentTerms;
    }

    public void setMasterPaymentTerms(MasterPaymentTerms masterPaymentTerms) {
      this.masterPaymentTerms = masterPaymentTerms;
    }
    
    @OneToOne
    @JoinColumn(name = "PROJECT_ID", referencedColumnName = "PROJECT_ID")
    public Project getProject() {
      return project;
    }

    public void setProject(Project project) {
      this.project = project;
    }
    
    @Column(name="OTHERS")
    public String getOthers() {
      return others;
    }

    public void setOthers(String others) {
      this.others = others;
    }
    
    @Override
    public String toString() {
    // TODO Auto-generated method stub
    return "[id : " + id + " dateOfIssue : " + dateOfIssue+"]" ;
    }
    
    @Transient
    public  String getEncryptId(){
      return EncrptBean.encrypt(id);
    }
    
    @Transient
    public String getFormattedDate() {
      return formattedDate;
    }
    @Transient
    public void setFormattedDate(String formattedDate) {
      this.formattedDate = formattedDate;
    }
    @Column(name="PO_NUMBER")
    public String getPoNumber() {
      return poNumber;
    }

    public void setPoNumber(String poNumber) {
      this.poNumber = poNumber;
    }

    @Column(name="CREATED_USER")
    public String getCreated_user() {
      return created_user;
    }
    public void setCreated_user(String created_user) {
      this.created_user = created_user;
    }
    @Column(name="CREATED_DATE")
    public Date getCreated_date() {
      return created_date;
    }
    public void setCreated_date(Date created_date) {
      this.created_date = created_date;
    }
    @Column(name="UPDATED_USER")
    public String getUpdated_user() {
      return updated_user;
    }
    public void setUpdated_user(String updated_user) {
      this.updated_user = updated_user;
    }
    @Column(name="UPDATED_DATE")
    public Date getUpdated_date() {
      return updated_date;
    }
    public void setUpdated_date(Date updated_date) {
      this.updated_date = updated_date;
    }
    @Transient
    public String getInvoices() {
      return invoices;
    }
    @Transient
    public void setInvoices(String invoices) {
      this.invoices = invoices;
    }
    
    @Transient
    public String getBalance() {
      return balance;
    }
    @Transient
    public void setBalance(String balance) {
      this.balance = balance;
    }

    @Override
    @Transient
    public List<String> getEncryptFieldsInfo() {
      // TODO Auto-generated method stub
      List<String> prop = new ArrayList<String>();
      prop.add("estimationAmount");
      return prop;
    }


}
