package com.erai.enterpriseconnect.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "FINANCIAL_YEAR")
public class FinancialYear {
	
	private Long financialYearId;
	private String FinancialYear;
	private String createdUser;
	private String updatedUser;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FINANCIAL_YEAR_ID")
	public Long getFinancialYearId() {
		return financialYearId;
	}
	public void setFinancialYearId(Long financialYearId) {
		this.financialYearId = financialYearId;
	}
	
	@Column(name = "FINANCIAL_YEAR")
	public String getFinancialYear() {
		return FinancialYear;
	}
	public void setFinancialYear(String financialYear) {
		FinancialYear = financialYear;
	}
	
	@Column(name = "CREATED_USER")
	public String getCreatedUser() {
		return createdUser;
	}
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	
	@Column(name = "UPDATED_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}
	
	
}
