/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;


import javax.persistence.*;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Cascade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;

import com.erai.enterpriseconnect.core.util.EncrptBean;
import com.erai.enterpriseconnect.listener.EntityToPersistListener;
import com.erai.enterpriseconnect.web.BillingsController;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Domain class for Entity Estimation
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "invoice")
@EntityListeners(EntityToPersistListener.class)
public class Invoice implements Auditable,Encryptable{
  
  private final Logger logger = LoggerFactory.getLogger(Invoice.class);
    private String invoiceId;
    private Date dateOfIssue;
    private Date plannedPayDate;
    private Country country;
    private String invoiceAmount;
    private String balance;
    private ClientProfile clientProfile;
    private UserProfile userProfile;
    private MasterPaymentTerms masterPaymentTerms;
    private Project project;
    private Estimation estimation;
    private BankProfile bankProfile;
    private String formattedDate;
    private String financialYear;
    private Set<WorkData> workData = new HashSet<WorkData>(0);
    private String created_user;
    private Date created_date;
    private String updated_user;
    private Date updated_date;

    @Id
    @Column(name="INVOICE_ID")
    public String getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(String invoiceId) {
        this.invoiceId = invoiceId;
    }
    @Column(name="DATE_OF_ISSUE")
    @DateTimeFormat(pattern="yyyy/MM/dd")
    public Date getDateOfIssue() {
        return dateOfIssue;
    }

    public void setDateOfIssue(Date dateOfIssue) {
        this.dateOfIssue = dateOfIssue;
    }

    @Column(name="INVOICE_AMOUNT")
    public String getInvoiceAmount() {
     return invoiceAmount;
    }

    public void setInvoiceAmount(String invoiceAmount) {
      this.invoiceAmount = invoiceAmount;
    }
    @Column(name="PL_PAY_DATE")
    public Date getPlannedPayDate() {
      return plannedPayDate;
    }

    public void setPlannedPayDate(Date plannedPayDate) {
      this.plannedPayDate = plannedPayDate;
    }
    @OneToOne
    @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID")
    public Country getCountry() {
      return country;
    }

    public void setCountry(Country country) {
      this.country = country;
    }
    
    @OneToOne
    @JoinColumn(name = "CLIENT_PROFILE_ID", referencedColumnName = "CLIENT_PROFILE_ID")
    public ClientProfile getClientProfile() {
      return clientProfile;
    }

    public void setClientProfile(ClientProfile clientProfile) {
      this.clientProfile = clientProfile;
    }
    
    @OneToMany( fetch = FetchType.EAGER, cascade = {CascadeType.ALL},mappedBy = "invoice")
    public Set<WorkData> getWorkData() {
      return this.workData;
    }

    public void setWorkData(Set<WorkData> workData) {
      this.workData = workData;
    }
    
    @OneToOne
    @JoinColumn(name = "USER_PROFILE_ID", referencedColumnName = "USER_PROFILE_ID")
    public UserProfile getUserProfile() {
      return userProfile;
    }

    public void setUserProfile(UserProfile userProfile) {
      this.userProfile = userProfile;
    }
    
    @OneToOne
    @JoinColumn(name = "PAYMENT_ID", referencedColumnName = "PAYMENT_ID")
    public MasterPaymentTerms getMasterPaymentTerms() {
      return masterPaymentTerms;
    }

    public void setMasterPaymentTerms(MasterPaymentTerms masterPaymentTerms) {
      this.masterPaymentTerms = masterPaymentTerms;
    }
    
    @OneToOne
    @JoinColumn(name = "PROJECT_ID", referencedColumnName = "PROJECT_ID")
    public Project getProject() {
      return project;
    }

    public void setProject(Project project) {
      this.project = project;
    }
    

    
    @Override
    public String toString() {
    // TODO Auto-generated method stub
    return "[id : " + invoiceId + " dateOfIssue : " + dateOfIssue + " country : " + 
        country.getMstCountry().getCountryName() + "]";
    }
    
    @Transient
    public  String getEncryptId(){
      return EncrptBean.encrypt(invoiceId);
    }
    
    @Transient
    public String getFormattedDate() {
      return formattedDate;
    }
    @Transient
    public void setFormattedDate(String formattedDate) {
      this.formattedDate = formattedDate;
    }
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ESTIMATION_ID", referencedColumnName = "ESTIMATION_ID")
    public Estimation getEstimation() {
      return estimation;
    }

    public void setEstimation(Estimation estimation) {
      this.estimation = estimation;
    }
    @OneToOne
    @JoinColumn(name = "BANK_ID", referencedColumnName = "BANK_ID")
    public BankProfile getBankProfile() {
      return bankProfile;
    }

    public void setBankProfile(BankProfile bankProfile) {
      this.bankProfile = bankProfile;
    }
    @Column(name="BALANCE")
    public String getBalance() {
      return balance;
    }

    public void setBalance(String balance) {
      this.balance = balance;
    }
    @Column(name="CREATED_USER")
    public String getCreated_user() {
      return created_user;
    }
    public void setCreated_user(String created_user) {
      this.created_user = created_user;
    }
    @Column(name="CREATED_DATE")
    public Date getCreated_date() {
      return created_date;
    }
    public void setCreated_date(Date created_date) {
      this.created_date = created_date;
    }
    @Column(name="UPDATED_USER")
    public String getUpdated_user() {
      return updated_user;
    }
    public void setUpdated_user(String updated_user) {
      this.updated_user = updated_user;
    }
    @Column(name="UPDATED_DATE")
    public Date getUpdated_date() {
      return updated_date;
    }
    public void setUpdated_date(Date updated_date) {
      this.updated_date = updated_date;
    }
    @Transient
    public String getFinancialYear(){
      return dateOfIssue.getYear()+"-"+(dateOfIssue.getYear()+1+"").substring(2);
    }
    @Transient
    public void setFinancialYear(String financialYear) {
      this.financialYear = financialYear;
    }

    @Override
    @Transient
    public List<String> getEncryptFieldsInfo() {
      // TODO Auto-generated method stub
      List<String> prop = new ArrayList<String>();
      prop.add("invoiceAmount");
      prop.add("balance");
      return prop;
    }
}
