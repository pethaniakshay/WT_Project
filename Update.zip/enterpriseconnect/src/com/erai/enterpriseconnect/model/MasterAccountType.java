/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Domain class for EntiTy role
 * 
 * @author WArun
 *
 */
@Entity
@Table(name = "mst_account_type")
public class MasterAccountType {
    private Long mstAccId;
    private String accType;
	
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="MST_ACC_ID")
    public Long getMstAccId() {
		return mstAccId;
	}
	public void setMstAccId(Long mstAccId) {
		this.mstAccId = mstAccId;
	}
	
	@Column(name="ACC_TYPE")
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
    
       
}
