/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.*;

import java.util.Set;

/**
 * Domain class for EntiTy role
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "mst_client_status")
public class MasterClientStatus {
    private Long statusId;
    private String statusName;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="STATUS_ID")
    public Long getStatusId() {
        return statusId;
    }

    public void setStatusId(Long statusId) {
        this.statusId = statusId;
    }
    
    @Column(name="STATUS_NAME")
    public String getStatusName() {
      return statusName;
    }

    public void setStatusName(String statusName) {
      this.statusName = statusName;
    }
}
