/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.*;

import java.util.Set;

/**
 * Domain class for EntiTy role
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "mst_client_type")
public class MasterClientType {
    private Long typeId;
    private String typeName;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="TYPE_ID")
    public Long getTypeId() {
        return typeId;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }
    
    @Column(name="TYPE_NAME")
    public String getTypeName() {
      return typeName;
    }

    public void setTypeName(String typeName) {
      this.typeName = typeName;
    }
}
