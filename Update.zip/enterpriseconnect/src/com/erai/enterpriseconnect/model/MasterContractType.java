/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.*;

import java.util.Set;

/**
 * Domain class for EntiTy role
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "mst_contract_type")
public class MasterContractType {
    private Long contractId;
    private String contractName;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="CONTRACT_ID")
    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }
    
    @Column(name="CONTRACT_NAME")
    public String getContractName() {
      return contractName;
    }

    public void setContractName(String contractName) {
      this.contractName = contractName;
    }
}
