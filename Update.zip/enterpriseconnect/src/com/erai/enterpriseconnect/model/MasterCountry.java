/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.*;

import java.util.Set;

/**
 * Domain class for EntiTy role
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "mst_country")
public class MasterCountry {
    private Long mstCountryId;
    private String countryName;
    private String currency;
    private String language;
    private String currencySymbol;

    @Column(name="CURRENCY_SYMBOL")
    public String getCurrencySymbol() {
      return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
      this.currencySymbol = currencySymbol;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="MST_COUNTRY_ID")
    public Long getMstCountryId() {
        return mstCountryId;
    }

    public void setMstCountryId(Long mstCountryId) {
        this.mstCountryId = mstCountryId;
    }
    
    @Column(name="COUNTRY_NAME")
    public String getCountryName() {
      return countryName;
    }

    public void setCountryName(String countryName) {
      this.countryName = countryName;
    }

    @Column(name="CURRENCY")
    public String getCurrency() {
      return currency;
    }

    public void setCurrency(String currency) {
      this.currency = currency;
    }

    @Column(name="LANGUAGE")
    public String getLanguage() {
      return language;
    }

    public void setLanguage(String language) {
      this.language = language;
    }

   
}
