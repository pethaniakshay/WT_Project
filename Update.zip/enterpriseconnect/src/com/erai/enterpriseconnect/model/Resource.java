package com.erai.enterpriseconnect.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Domain class for Entity Resources
 * 
 * @author mukesh
 *
 */

@Entity
@Table(name = "resources")
public class Resource {
  // private FinancialYear financialYear;
  private Long resourceId;
  private String location;
  private Project projectId;
  private Date startDate;
  private Date endDate;
  private String volume;
  private String createdUser;
  private Employee employee;
  private MasterRole masterRole;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "RESOURCES_ID")
  public Long getResourceId() {
    return resourceId;
  }

  public void setResourceId(Long resourceId) {
    this.resourceId = resourceId;
  }

  @OneToOne
  @JoinColumn(name = "EMP_ID", referencedColumnName = "EMP_ID")
  public Employee getEmployee() {
    return employee;
  }

  public void setEmployee(Employee employee) {
    this.employee = employee;
  }

  @OneToOne
  @JoinColumn(name = "ROLE_ID", referencedColumnName = "ROLE_ID")
  public MasterRole getMasterRole() {
    return masterRole;
  }

  public void setMasterRole(MasterRole masterRole) {
    this.masterRole = masterRole;
  }


  @Column(name = "LOCATION")
  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  @ManyToOne
  @JoinColumn(name = "PROJECT_ID", referencedColumnName = "PROJECT_ID")
  public Project getProjectId() {
    return projectId;
  }

  public void setProjectId(Project projectId) {
    this.projectId = projectId;
  }

  @Column(name = "START_DATE")
  public Date getStartDate() {
    return startDate;
  }

  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  @Column(name = "END_DATE")
  public Date getEndDate() {
    return endDate;
  }

  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }

  @Column(name = "CREATED_USER")
  public String getCreatedUser() {
    return createdUser;
  }

  public void setCreatedUser(String createdUser) {
    this.createdUser = createdUser;
  }

  @Column(name = "VOLUME")
  public String getVolume() {
    return volume;
  }

  public void setVolume(String volume) {
    this.volume = volume;
  }


  /*
   * @ManyToOne(fetch=FetchType.EAGER)
   * 
   * @JoinColumn(name="FINANCIAL_YEAR_ID", nullable=false) public FinancialYear
   * getFinancialYear() { return financialYear; } public void
   * setFinancialYear(FinancialYear financialYear) { this.financialYear =
   * financialYear; }
   */

}
