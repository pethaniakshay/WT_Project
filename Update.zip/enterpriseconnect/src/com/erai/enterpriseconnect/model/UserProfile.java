/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.*;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Domain class for Entity User
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "user_profile")
public class UserProfile {
	private Long userProfileId;
	private String name;
	private String email;
	private String password;
	private String passwordConfirm;
	private String empNumber;
	private MasterRole masterRole;
	private Date dateOfJoining;
	private BankProfile bankProfile;
	
	private Date dateOfBirth;
    private String imagePath;
    private String timeZone;
    private String created_user;
    private Date created_date;
    private String updated_user;
    private Date updated_date;
	
	@Column(name = "DATE_OF_JOIN")
	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	private Set<Role> roles;
	private Set<Country> countries;

	private Set<ClientProfile> clientProfile = new HashSet<ClientProfile>(0);
	
	 @OneToOne
	 @JoinColumn(name = "ROLE_ID", referencedColumnName = "ROLE_ID")
	  public MasterRole getMasterRole() {
	    return masterRole;
	  }

	  public void setMasterRole(MasterRole masterRole) {
	    this.masterRole = masterRole;
	  }

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "userProfile")
	public Set<ClientProfile> getClientProfile() {
		return clientProfile;
	}

	public void setClientProfile(Set<ClientProfile> clientProfile) {
		this.clientProfile = clientProfile;
	}

	

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "userProfile")
	public Set<Country> getCountries() {
		return countries;
	}

	public void setCountries(Set<Country> countries) {
		this.countries = countries;
	}

	@Id
	@Column(name = "USER_PROFILE_ID")
	public Long getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}

	@Column(name = "NAME")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "EMAIL")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "EMP_NUMBER")
	public String getEmpNumber() {
		return empNumber;
	}

	public void setEmpNumber(String empNumber) {
		this.empNumber = empNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Transient
	public String getPasswordConfirm() {
		return passwordConfirm;
	}

	public void setPasswordConfirm(String passwordConfirm) {
		this.passwordConfirm = passwordConfirm;
	}
	
	@LazyCollection(LazyCollectionOption.FALSE)
	@ManyToMany
	@JoinTable(name = "user_role", joinColumns = @JoinColumn(name = "USER_ID"), inverseJoinColumns = @JoinColumn(name = "ROLE_ID"))
	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}
	@Column(name="DATE_OF_BIRTH")
  	public Date getDateOfBirth() {
  		return dateOfBirth;
  	}
  	public void setDateOfBirth(Date dateOfBirth) {
  		this.dateOfBirth = dateOfBirth;
  	}
	
	@Column(name="IMAGE_FILE_NAME")
  	public String getImagePath() {
  		return imagePath;
  	}
  	public void setImagePath(String imagePath) {
  		this.imagePath = imagePath;
  	}
  	
  	 @Column(name="CREATED_USER")
     public String getCreated_user() {
       return created_user;
     }
     public void setCreated_user(String created_user) {
       this.created_user = created_user;
     }
     @Column(name="CREATED_DATE")
     public Date getCreated_date() {
       return created_date;
     }
     public void setCreated_date(Date created_date) {
       this.created_date = created_date;
     }
     @Column(name="UPDATED_USER")
     public String getUpdated_user() {
       return updated_user;
     }
     public void setUpdated_user(String updated_user) {
       this.updated_user = updated_user;
     }
     @Column(name="UPDATED_DATE")
     public Date getUpdated_date() {
       return updated_date;
     }
     public void setUpdated_date(Date updated_date) {
       this.updated_date = updated_date;
     }
     @Column(name="TIMEZONE")
     public String getTimeZone() {
       return timeZone;
     }

     public void setTimeZone(String timeZone) {
       this.timeZone = timeZone;
     }

     
}
