/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.erai.enterpriseconnect.model.BankProfile;

/**
 * JPA Repository for Bank Profile
 * 
 * @author Warun
 *
 */
public interface BankProfileRepository extends JpaRepository<BankProfile, Long>{
  
  List<BankProfile> findAll();
  
  	public BankProfile findOne(Long id);
  	
  	/*@Query("UPDATE BankProfile b SET b.bankName = :bankName,b.countryId = :countryId,b.branchName = :branchName,"
  			+ "b.swiftCode = :swiftCode,b.mstAccId = :mstAccId,b.accountNo = :accountNo,b.accountType = :accountType"
  			+ "b.accountName = :accountName WHERE b.bankId = :bankId")
    int updateBank(@Param("bankId") Long bankId, @Param("bankName") String bankName, @Param("countryId") String countryId, 
    		@Param("branchName") String branchName,@Param("swiftCode") String swiftCode,@Param("mstAccId") String mstAccId,
    		@Param("accountNo") String accountNo,@Param("accountType") String accountType,@Param("accountName") String bankAddress);*/
}
