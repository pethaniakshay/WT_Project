/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.repository;

import java.util.List;

import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.Role;
import com.erai.enterpriseconnect.model.UserProfile;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * JPA Repository for role
 * 
 * @author anand
 *
 */
public interface ClientProfileRepository extends JpaRepository<ClientProfile, Long>{
  
  List<ClientProfile> findAll();

  ClientProfile findByClientProfileId(long id);

  List<ClientProfile> findAllByCountry(Country country);

  List<ClientProfile> findAllByCountryAndUserProfile(Country country,
      UserProfile userProfile);
  
}
