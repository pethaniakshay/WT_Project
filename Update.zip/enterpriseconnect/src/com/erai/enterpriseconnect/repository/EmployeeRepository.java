/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * Created on : 22-8-2017
 * Author     : Akshay Pethani
 * Version    : 1.0 
 */
package com.erai.enterpriseconnect.repository;

import java.util.List;

import com.erai.enterpriseconnect.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * JPA Repository for role
 * @author Akshay Pethani
 */
public interface EmployeeRepository extends JpaRepository<Employee, Long>{
  /* (non-Javadoc)
   * @see org.springframework.data.jpa.repository.JpaRepository#findAll()
   */
  List<Employee> findAll();

  /**
   * @param empId
   * @return
   */
  Employee findByEmpId(long empId);
}
