/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erai.enterpriseconnect.model.FinancialYear;

/**
 * JPA Repository for role
 * 
 * @author Warun
 *
 */
public interface FinancialYearRepository extends JpaRepository<FinancialYear, Long>{
  
	FinancialYear findByFinancialYear(String financialYear);
}
