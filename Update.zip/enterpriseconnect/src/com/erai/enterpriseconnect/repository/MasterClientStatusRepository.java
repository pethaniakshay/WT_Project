package com.erai.enterpriseconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.MasterClientStatus;

public interface MasterClientStatusRepository extends JpaRepository<MasterClientStatus, Long> {
	 List<MasterClientStatus> findAll();
	 MasterClientStatus findByStatusId(long id);
}
