package com.erai.enterpriseconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erai.enterpriseconnect.model.MasterClientStatus;
import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterContractType;

public interface MasterContractTypeRepository extends JpaRepository<MasterContractType, Long> {
  List<MasterContractType> findAll();
  MasterContractType findByContractId(long contractId);
}
