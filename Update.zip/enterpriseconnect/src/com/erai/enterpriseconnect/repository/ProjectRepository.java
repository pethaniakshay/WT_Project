/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Project;

/**
 * JPA Repository for Project
 * 
 * @author Warun
 *
 */
public interface ProjectRepository extends JpaRepository<Project, Long> {

	List<Project> findAll();
	Project findByProjectId(long id);
	List<Project> findAllByClientProfile(ClientProfile clientProfile);

}
