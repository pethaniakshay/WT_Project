/*
 * Copyright 2017 (C) <Nexware Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.security;

import java.io.IOException;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.i18n.LocaleContext;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.core.util.RequestUtil;

public class LogoutPropagateRedirectStrategy extends DefaultRedirectStrategy {


  private final Logger logger = LoggerFactory
      .getLogger(LogoutPropagateRedirectStrategy.class);


  /* (non-Javadoc)
   * 
   * @see org.springframework.security.web.DefaultRedirectStrategy#sendRedirect(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.String)
   */
  public void sendRedirect(HttpServletRequest request,
      HttpServletResponse response, String url) throws IOException {
    String redirectUrl = Constants.LOGOUT;
    String lang = RequestUtil.getParamValue(request.getQueryString(), Constants.LANGUAGE);
    //if (lang != null && lang.equals(Constants.JP_LOCAL))
      redirectUrl = redirectUrl + Constants.PARAM_SEP + Constants.LANGUAGE + Constants.EQUAL + lang;
    super.sendRedirect(request, response, redirectUrl);
  }
}
