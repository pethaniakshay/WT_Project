/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * Created on : 14-8-2017
 * Author     : Akshay pethani
 * Version    : 1.0
 */

package com.erai.enterpriseconnect.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.erai.enterpriseconnect.model.Attendance;

/**
 * Service Interface for the Attendance module
 * @author Akshay Pethani
 *
 */
public interface AttendanceService {
  /**
   * @param empID
   * @param year
   * @param country
   * @param month
   * @return
   */
  List<Attendance> searchResult(Long empID , int year, String country, String month);
  /**
   * @return
   */
  Map<String, Object> listUsers();
  /**
   * @param year
   * @param country
   * @param month
   * @param role
   * @return
   */
  List<Attendance> searchAttendanceList(String year, String country,String month, String role);

  /**
   * @return
   */
  Map<String, Object> search();

  /**
   * @param country
   * @param empId
   * @param fromDate
   * @param toDate
   * @return
   */
  List<Attendance> searchAttListAjax(String country,String empId,Date fromDate, Date toDate);

  /**
   * @return
   */
  String getEmployeeCountryName();

  boolean editAttendance(String resposneType,String attendanceId, String intm, String outtm, String remarks);
}
