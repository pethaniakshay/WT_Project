/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.erai.enterpriseconnect.model.BankProfile;
import com.erai.enterpriseconnect.model.CurrencyExchange;
import com.erai.enterpriseconnect.model.MasterAccountType;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.repository.BankProfileRepository;
import com.erai.enterpriseconnect.repository.CurrencyExchageRepository;
import com.erai.enterpriseconnect.repository.MasterAccountTypeRepository;
import com.erai.enterpriseconnect.repository.RoleRepository;

/**
 * UserServiceImpl - User Related details
 * @author Warun
 *
 */
@Service
public class BankProfileServiceImpl implements BankProfileService {
    @Autowired
    private BankProfileRepository bankProfileRepository;
    @Autowired
    private MasterCountryService masterCountryRepository;
    @Autowired
    private MasterAccountTypeRepository masterAccountTypeRepository;
    @Autowired
    private CurrencyExchageRepository currencyExchageRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Override
	public List<MasterCountry> findAllCountry() {
		// TODO Auto-generated method stub
    	
		return masterCountryRepository.findAll();
	}
    
    @Override
    public List<BankProfile> findAll() {
      // TODO Auto-generated method stub
      return bankProfileRepository.findAll();
    }
    
    @Override
	public List<CurrencyExchange> findAllCurrencyExchangeRate() {
		// TODO Auto-generated method stub
		return currencyExchageRepository.findAll();
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public Boolean addBank(BankProfile bankProfile) {
		Boolean status=true;
		// TODO Auto-generated method stub
		try {
			bankProfileRepository.save(bankProfile);
	    }
	    catch (DataIntegrityViolationException e) {
	    	status=false;
	    }
		return status;
	}

	@Override
	public BankProfile findOne(Long id) {
		BankProfile bankProfile=bankProfileRepository.findOne(id);
		return bankProfile != null ? bankProfile : null;
	}

	@Override
	public BankProfile findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MasterAccountType> findAllAccountType() {
		// TODO Auto-generated method stub
		return masterAccountTypeRepository.findAll();
	}

	/*@Override
	@Transactional
	public int updateBankPforile(BankProfile bankProfile) {
		// TODO Auto-generated method stub
		return bankProfileRepository.updateBank(bankProfile.getBankId(),bankProfile.getBankName(),bankProfile.getCountry().getCountryId(),bankProfile.getBranchName()
				,bankProfile.getSwiftCode(),bankProfile.getAccountType().getMstAccId(),bankProfile.getAccountNo(),bankProfile.getAccountName(),bankProfile.getBankAddress());
	}*/
	

}
