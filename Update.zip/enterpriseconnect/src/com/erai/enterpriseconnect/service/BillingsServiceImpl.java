/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.core.util.DateUtil;
import com.erai.enterpriseconnect.core.util.EncrptBean;
import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.Invoice;
import com.erai.enterpriseconnect.model.MasterContractType;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.MasterPaymentTerms;
import com.erai.enterpriseconnect.model.MasterTax;
import com.erai.enterpriseconnect.model.Project;
import com.erai.enterpriseconnect.model.ProjectVolume;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.model.WorkData;
import com.erai.enterpriseconnect.repository.BillingsRepository;
import com.erai.enterpriseconnect.repository.RoleRepository;
import com.erai.enterpriseconnect.repository.UserRepository;
import com.erai.enterpriseconnect.web.BillingsController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;


/**
 * UserServiceImpl - User Related details
 * @author anand
 *
 */
@Service
public class BillingsServiceImpl implements BillingsService {
  private final Logger logger = LoggerFactory.getLogger(BillingsServiceImpl.class);
    @Autowired
    private BillingsRepository billingsRepository;
    
    @Autowired
    private DateUtil dateUtil;
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private ProjectService projectService;

    @Autowired
    private ClientProfileService clientProfileService;

    @Autowired
    private CountryService countryService;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private WorkDataService workDataService;

    @Autowired
    private MasterContractTypeService masterContractTypeService;

    @Autowired
    private MasterPaymentTermsService masterPaymentTermsService;

    @Autowired
    private ProjectVolumeService projectVolumeService;

    @Autowired
    private MasterCountryService masterCountryService;
    
    @Autowired
    private MasterTaxService masterTaxService;
    
    @Autowired
    private InvoiceService invoiceService;


    @Override
    public List<Estimation> findAll() {
      // TODO Auto-generated method stub
      return billingsRepository.findAll();
    }

    @Override
    public void save(Estimation estimation) {
      billingsRepository.saveAndFlush(estimation);
    }
  

    @Override
    public Estimation findById(String id) {
      // TODO Auto-generated method stub
      return billingsRepository.findById(id);
    }

    @Override
    public List<Estimation> findAllByUserProfile(UserProfile userProfile) {
      // TODO Auto-generated method stub
      return  billingsRepository.findAllByUserProfile(userProfile);
    }
    
    @Override
    public List<Estimation> searchResult(UserProfile userProfile, int year, String country, String month) {
      String query = "SELECT e FROM Estimation e WHERE e.country.mstCountry.countryName = ? AND e.dateOfIssue BETWEEN ? AND ?";
      if (userProfile != null){
        query = query + " AND e.userProfile = ?";
      }
      Query q = entityManager.createQuery(query);
      logger.debug("country:" + country);
      q.setParameter(1, country);
      logger.debug("query :" + query);
      
      switch (month) {
      case "ALL":
        q.setParameter(2, DateUtil.getSqlDate((year+"0401")), TemporalType.DATE);
        q.setParameter(3, DateUtil.getSqlDate((year + 1)+"0331") , TemporalType.DATE);
           break;
      case "Apr":
        q.setParameter(2, DateUtil.getSqlDate((year+"0401")), TemporalType.DATE);
        q.setParameter(3, DateUtil.getSqlDate((year)+"0430") , TemporalType.DATE);
           break;
      case "May":
        q.setParameter(2, DateUtil.getSqlDate((year+"0501")), TemporalType.DATE);
        q.setParameter(3, DateUtil.getSqlDate((year)+"0531") , TemporalType.DATE);
           break;
      case "Jun":
        q.setParameter(2, DateUtil.getSqlDate((year+"0601")), TemporalType.DATE);
        q.setParameter(3, DateUtil.getSqlDate((year)+"0630") , TemporalType.DATE);
           break;
      case "Jul":
        q.setParameter(2, DateUtil.getSqlDate((year+"0701")), TemporalType.DATE);
        q.setParameter(3, DateUtil.getSqlDate((year)+"0731") , TemporalType.DATE);
           break;
      case "Aug":
        q.setParameter(2, DateUtil.getSqlDate((year+"0801")), TemporalType.DATE);
        q.setParameter(3, DateUtil.getSqlDate((year)+"0831") , TemporalType.DATE);
        break;
   case "Sep":
     q.setParameter(2, DateUtil.getSqlDate((year+"0901")), TemporalType.DATE);
     q.setParameter(3, DateUtil.getSqlDate((year)+"0930") , TemporalType.DATE);
        break;
   case "Oct":
     q.setParameter(2, DateUtil.getSqlDate((year+"1001")), TemporalType.DATE);
     q.setParameter(3, DateUtil.getSqlDate((year)+"1031") , TemporalType.DATE);
        break;
   case "Nov":
     q.setParameter(2, DateUtil.getSqlDate((year+"1101")), TemporalType.DATE);
     q.setParameter(3, DateUtil.getSqlDate((year)+"1130") , TemporalType.DATE);
        break;
   case "Dec":
     q.setParameter(2, DateUtil.getSqlDate((year+"1201")), TemporalType.DATE);
     q.setParameter(3, DateUtil.getSqlDate((year)+"1231") , TemporalType.DATE);
        break;
   case "Jan":
     q.setParameter(2, DateUtil.getSqlDate(((year +1)+"0101")), TemporalType.DATE);
     q.setParameter(3, DateUtil.getSqlDate((year + 1)+"0131") , TemporalType.DATE);
case "Feb":
  q.setParameter(2, DateUtil.getSqlDate(((year +1)+"0201")), TemporalType.DATE);
  if(DateUtil.isLeapYear((year + 1))){
  q.setParameter(3, DateUtil.getSqlDate((year + 1)+"0229") , TemporalType.DATE);
  } else {
    q.setParameter(3, DateUtil.getSqlDate((year + 1)+"0228") , TemporalType.DATE); 
  }
     break;
case "Mar":
  q.setParameter(2, DateUtil.getSqlDate(((year +1)+"0301")), TemporalType.DATE);
  q.setParameter(3, DateUtil.getSqlDate((year + 1)+"0331") , TemporalType.DATE);
  break;
     default:
           break;
     }
      if (userProfile != null){
        q.setParameter(4, userProfile);
      }
List<Estimation> e = q.getResultList();
      logger.debug("Result List for User :" + e);
      return e;
    }

    @Override
    public List<Estimation> searchEstimation(UserProfile userProfile, int year,
        String country, ClientProfile clientProfile) {
      String query = "SELECT e FROM Estimation e WHERE e.country.mstCountry.countryName = ? AND e.dateOfIssue BETWEEN ? AND ? AND e.userProfile = ? AND e.clientProfile = ?";
      Query q = entityManager.createQuery(query);
      q.setParameter(1, country);
      q.setParameter(2, DateUtil.getSqlDate((year+"0401")), TemporalType.DATE);
      q.setParameter(3, DateUtil.getSqlDate((year + 1)+"0331") , TemporalType.DATE);
      q.setParameter(4, userProfile);
      q.setParameter(5, clientProfile);
      List<Estimation> e = q.getResultList();
      logger.debug("Result List for User :" + e);
      return e;
    }

    @Override
    public Estimation merge(Estimation estimation) {
      return entityManager.merge(estimation);
      
    }

    @Override
    public Map<String, Object> createEstimation(Estimation est) {
      Map<String, Object> estValues = new  HashMap<String, Object>();
      UserProfile userProfile = userService.findByEmail(securityService
          .findLoggedInUsername());
      List<ClientProfile> clients = new ArrayList<ClientProfile>();
      List<Project> projects = new ArrayList<Project>();
      List<MasterContractType> contractTypes = masterContractTypeService
          .findAll();
      List<MasterPaymentTerms> paymentTerms = masterPaymentTermsService.findAll();
      List<ProjectVolume> projectVolumes = projectVolumeService.findAll();
      for (ClientProfile clientProfile : userProfile.getClientProfile()) {
        clients.add(clientProfile);
        for (Project project : clientProfile.getProjects()) {
          projects.add(project);
        }
      }
      int size = est.getWorkData().size();
      for (int i = 0; i < 3- size; i++) {
        est.getWorkData().add(new WorkData());
      }
      List<Country> countries = new ArrayList<Country>();
      if(securityService.findLoggedInUserRole().equals(Constants.ROLE_ADMIN)){
        countries = countryService.findAll();
      }else {
       countries = countryService.findByUserProfile(userProfile);
      }
      List<MasterTax> taxList = masterTaxService.findByMstCountry(countries.get(0).getMstCountry());
      estValues.put("clients", clients);
      estValues.put("contractTypes", contractTypes);
      estValues.put("paymentTerms", paymentTerms);
      estValues.put("projects", projects);
      estValues.put("projectVolumes", projectVolumes);
      estValues.put("countries",countries );
      estValues.put("estimation", est);
      estValues.put("taxList", taxList);
      estValues.put("defaultCountry",countries.get(0).getMstCountry().getCountryName() );
      estValues.put("defaultCurrency",countries.get(0).getMstCountry().getCurrencySymbol());
      return estValues;
    }

    @Override
    public Map<String, Object> viewEstimation(Estimation est) {
      Map<String, Object> estView = new  HashMap<String, Object>();
      List<MasterCountry> mstCountryList = masterCountryService.findAll();
      estView.put("countryList", mstCountryList);
      double subTotal = 0.0;
      double tax = 0.0;
      double total = 0.0 ;
      double mgmtAmt = 0.0;
      double mgmtTax = 0.0;
      double taxValue = 0.0;
      logger.debug("workdata size :" + est.getWorkData().size());
      for(WorkData wrkData : est.getWorkData()){
        if(!wrkData.getIsWorkData()){
          estView.put("mgmtData", wrkData);
          mgmtAmt = (wrkData.getManagementCost() != null) ? Double.parseDouble(wrkData.getManagementCost()) : mgmtAmt;
          mgmtTax = (wrkData.getManagementCost() != null) ? Double.parseDouble(wrkData.getTax()) : mgmtTax;
        }else {
          double amount = wrkData.getNoOfResources() * Double.parseDouble(wrkData.getRate());
          subTotal = subTotal + amount;
          logger.debug("amount:" + amount);
          logger.debug("subtotal:" + subTotal);
          if (wrkData.getTax() != null) {
            tax = tax + (amount * (Double.parseDouble(wrkData.getTax())) / 100);
            taxValue = Double.parseDouble(wrkData.getTax());
            logger.debug("tax:" + tax);
          }
        }
      }
      estView.put("estimation", est);
      double mgmtAmtCalc = subTotal * mgmtAmt/100;
      subTotal = subTotal + mgmtAmtCalc;
      tax = tax + (mgmtAmtCalc * mgmtTax/100);
      total = subTotal + tax;
      taxValue = (taxValue == 0.0) ? mgmtTax : taxValue;
      estView.put("taxPercent", taxValue);
      estView.put("subTotal", String.format("%.2f", subTotal));
      estView.put("tax", String.format("%.2f", tax));
      estView.put("total", String.format("%.2f", total));
      estView.put("defaultCurrency",est.getCountry().getMstCountry().getCurrencySymbol());
      estView.put("defaultCountry",est.getCountry().getMstCountry().getCountryName());
      return estView;
    }

    public Set<WorkData> getWorkData(Map<String, String[]> map) {
      Set<WorkData> workSet = new HashSet<WorkData>();
      Map<String, WorkData> workMap = new HashMap<String, WorkData>();
      String tax = "";
      if(map.get("taxValue").length > 0){
        tax = map.get("taxValue")[0];
      }
      try {
        for (Entry<String, String[]> entry : map.entrySet()) {
          if (entry.getKey().startsWith("workData")
              && (!entry.getValue()[0].equals(""))) {
            String key = entry.getKey();
            String type = key.split("\\.")[1];
            String index = key.split("\\.")[0].split("workData")[1];
            if (!workMap.containsKey(index)) {
              WorkData wrkData = new WorkData();
              wrkData.setDisplayOrder(Integer.parseInt(index));
              workMap.put(index, wrkData);
            }
            switch (type) {
            case "particular":
              workMap.get(index).setParticular(entry.getValue()[0]);
              break;
            case "noOfResources":
              workMap.get(index).setNoOfResources(
                  Integer.parseInt(entry.getValue()[0]));
              break;
            case "rate":
              workMap.get(index).setRate(entry.getValue()[0]);
              break;
            case "tax":
              workMap.get(index).setTax(tax);
              break;
            case "projectVolume":
              ProjectVolume projectVolume = projectVolumeService
                  .findByVolumeId(Integer.parseInt(entry.getValue()[0]));
              workMap.get(index).setProjectVolume(projectVolume);
              break;
            default:
              break;
            }
          }
        }
        for (Map.Entry<String, WorkData> entry : workMap.entrySet()) {
          WorkData workData = (WorkData) entry.getValue();
          logger.debug("rate:" , workData.getRate());
          if((!StringUtils.isEmpty(workData.getParticular())) && 
             (!StringUtils.isEmpty(workData.getNoOfResources())) && 
             (!StringUtils.isEmpty(workData.getRate())) &&
             (Double.parseDouble(workData.getRate()) != 0) &&
             (workData.getNoOfResources() != 0)){
            workData.setIsWorkData(true);
            workSet.add(workData);
        } 
        }
        if(map.get("mgmt").length > 0 && !map.get("mgmt")[0].equals("0") ){
          WorkData mngmtworkData = new WorkData();
          mngmtworkData.setParticular("Management Cost");
          mngmtworkData.setIsWorkData(false);
          mngmtworkData.setManagementCost(map.get("mgmt")[0]);
          if(map.get("mgmtTax") != null && map.get("mgmtTax").length > 0){
            mngmtworkData.setTax(tax);
          }
          workSet.add(mngmtworkData);
        }
      } catch (Exception e) {
        e.printStackTrace();
        logger.error("Error:" , e.getMessage());
      }
      logger.error("success:" + workSet.size());
      return workSet;
    }

    @Override
    public void saveEstimation(Set<WorkData> workDataSet,
        Estimation estimation, String countryCode) {
      // TODO Auto-generated method stub
      estimation.setId(countryCode.substring(0, 2) + new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()));
      for (WorkData wrkData : workDataSet) {
        wrkData.setEstimation(estimation);
        logger.debug("properties :" + wrkData);
      }
      estimation.setWorkData(workDataSet);
      logger.debug("size" + estimation.getWorkData().size());
      UserProfile userProfile = userService.findByEmail(securityService
          .findLoggedInUsername());
      logger.debug("amount :" + estimation.getEstimationAmount());
      estimation.setUserProfile(userProfile);
      estimation.setCountry(countryService.findByCountryName(countryCode));
      this.save(estimation);
    }

    @Override
    public void updateEstimation(Set<WorkData> workDataSet,
        Estimation estimation, Estimation est, String countryCode) {
      Map<Integer, Long> idMap = new HashMap<Integer, Long>();
      for (WorkData wrkRecord : est.getWorkData()) {
        idMap.put(wrkRecord.getDisplayOrder(), wrkRecord.getWorkDataId());
      }
      est.getWorkData().clear();
      for (WorkData wrkData : workDataSet) {
        wrkData.setEstimation(est);
        logger.debug("existing id:" + idMap.get(wrkData.getDisplayOrder()));
        if(idMap.get(wrkData.getDisplayOrder()) != null){
          wrkData.setWorkDataId(idMap.get(wrkData.getDisplayOrder()));
        }
        logger.debug("properties :" + wrkData);
      }
      est.getWorkData().addAll(workDataSet);
      logger.debug("after size:" + est.getWorkData());
      est.setCountry(estimation.getCountry());
      est.setProject(estimation.getProject());
      est.setEstimationValidity(estimation.getEstimationValidity());
      est.setEstimationAmount(estimation.getEstimationAmount());
      logger.debug("size" + estimation.getWorkData().size());
      UserProfile userProfile = userService.findByEmail(securityService
          .findLoggedInUsername());
      est.setUserProfile(userProfile);
     
      est.setCountry(countryService.findByCountryName(countryCode));
      this.save(est);
      
    }

    @Override
    public  Map<String, Object> listEstimation() {
      Map<String, Object> estValues = new  HashMap<String, Object>();
      List<Estimation> estList = null;
      int year = Calendar.getInstance().get(Calendar.YEAR);
      String role = securityService.findLoggedInUserRole();
      logger.debug("role:" + role);
      if (role.equals("ROLE_ADMIN")) {
        estList = searchResult(null, year, "JAPAN", "ALL");
      } else {
        UserProfile userProfile = userService.findByEmail(securityService.findLoggedInUsername());
        estList = searchResult(userProfile, year, "JAPAN", "ALL");
      }
      logger.debug("estList:" + estList);
      for(Estimation est :estList){
        for(Invoice inv : invoiceService.findAllByEstimation(est)){
          logger.debug(" Unit Invoice :" + inv.getInvoiceId());
          est.setInvoices(est.getInvoices() + " " + inv.getInvoiceId());
        }
        logger.debug(" Final Invoices :" + est.getInvoices());
      }
      // List of countries
      List<MasterCountry> mstCountryList = masterCountryService.findAll();
      estValues.put("estimations", estList);
      estValues.put("year", year);
      estValues.put("countryList",mstCountryList);
      return estValues;
      
    }

    @Override
    public List<Estimation> searchEstList(String year, String country,
        String month, String role) {
      int yearInt = Integer.parseInt(year);
      List<Estimation> estList = null;
     
      logger.debug("country:" + country);
      if (role.equals(Constants.ROLE_ADMIN)) {
        estList = searchResult(null, yearInt, country, month);
      } else {
        UserProfile userProfile = userService.findByEmail(securityService
            .findLoggedInUsername());
        estList = searchResult(userProfile, yearInt, country,
            month);
      }
      for(Estimation est :estList){
        for(Invoice inv : invoiceService.findAllByEstimation(est)){
          if(est.getInvoices() == null){
          est.setInvoices( inv.getInvoiceId());
          } else {
            est.setInvoices( est.getInvoices() + " " + inv.getInvoiceId());
          }
        }
      }
      return estList;
    }

    @Override
    public Map<String, Object> search() {
      Map<String, Object> estValues = new  HashMap<String, Object>();
      int year = Calendar.getInstance().get(Calendar.YEAR);
      String role = securityService.findLoggedInUserRole();
      ClientProfile clientProfile = null;
      List<ClientProfile> clientList = new ArrayList<ClientProfile>();
      List<UserProfile> userList = userService.findAll();
      List<MasterCountry> mstCountryList = masterCountryService.findAll();
      logger.debug("role:" + role);
      List<Estimation> estList = null;
      UserProfile userProfile = null;
      if (role.equals("ROLE_ADMIN")) {
        userProfile = userList.get(0);
        clientList = clientProfileService.findAll();
        clientProfile = clientList.get(0);
        estList = searchEstimation(userProfile, year, "JAPAN",
            clientProfile);
      } else {
        userProfile = userService.findByEmail(securityService
            .findLoggedInUsername());
        clientList.addAll(userProfile.getClientProfile());
        clientProfile = clientList.get(0);
        estList =searchEstimation(userProfile, year, "JAPAN",
            clientProfile);
      }
      estValues.put("estimations", estList);
      estValues.put("userProfile", userProfile);
      estValues.put("userProfiles", userList);
      estValues.put("clientProfiles", clientList);
      estValues.put("countryList", mstCountryList);
      estValues.put("year", year);
      return estValues;
    }

    @Override
    public List<Estimation> searchEstListAjax(String year, String country,
        String client, String user) {
      List<Estimation> estList = null;
      String role = securityService.findLoggedInUserRole();
      logger.debug("role:" + role);
      UserProfile userProfile = null;
      long clientId = Long.parseLong(client);
      int yearInt = Integer.parseInt(year);
      ClientProfile clientProfile = clientProfileService
          .findByClientProfileId(clientId);
      if (role.equals("ROLE_ADMIN")) {
        long userId = Long.parseLong(user);
        userProfile = userService.findOne(userId);
        estList = searchEstimation(userProfile, yearInt, country,
            clientProfile);
      } else {
        userProfile = userService.findByEmail(securityService
            .findLoggedInUsername());
        estList = searchEstimation(userProfile, yearInt, country,
            clientProfile);
      }
      return estList;
    }

    @Override
    public List<Estimation> findAllByClientProfile(ClientProfile clientProfile) {
      // TODO Auto-generated method stub
      return billingsRepository.findAllByClientProfile(clientProfile);
    }

    @Override
    public void delete(Estimation estimation) {
      // TODO Auto-generated method stub
       billingsRepository.delete(estimation);
      
    }

}
