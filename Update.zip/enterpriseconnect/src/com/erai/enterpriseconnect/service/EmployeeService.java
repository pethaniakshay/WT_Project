/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * Created on : 22-08-2017
 * Author     : Akshay Pethani
 * Version    : 1.0
 */
package com.erai.enterpriseconnect.service;

import java.util.List;

import com.erai.enterpriseconnect.model.Employee;

/**
 * Interface for security service
 * @author anand
 */
public interface EmployeeService {
  /**
   * @return username
   */
  List<Employee> findAll();

  /**
   * @param EmpId
   * @return
   */
  Employee findByEmpId(long EmpId);

  /**
   * @param countryName
   * @return
   */
  List<Employee> findAllByCountry(String countryName);
}
