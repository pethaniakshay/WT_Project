/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * Created on : 22-08-2017
 * Author     : Akshay Pethani
 * Version    : 1.0
 */
package com.erai.enterpriseconnect.service;

import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.model.Employee;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 * MasterCountryServiceImpl - Country Related details
 * @author anand
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {
  @Autowired
  private EmployeeRepository employeeRepository;

  @Autowired
  private MasterCountryService masterCountryService;

  @Autowired
  private SecurityService securityService;

  @Autowired
  private CountryService countryService;

  @Autowired
  private UserService userService;

  @PersistenceContext
  private EntityManager entityManager;

  /* (non-Javadoc)
   * @see com.erai.enterpriseconnect.service.EmployeeService#findAll()
   */
  @Override
  public List<Employee> findAll() {
    // TODO Auto-generated method stub
    return employeeRepository.findAll();
  }

  /* (non-Javadoc)
   * @see com.erai.enterpriseconnect.service.EmployeeService#findByEmpId(long)
   */
  @Override
  public Employee findByEmpId(long empId) {
    // TODO Auto-generated method stub
    return employeeRepository.findByEmpId(empId);
  }

  /* (non-Javadoc)
   * @see com.erai.enterpriseconnect.service.EmployeeService#findAllByCountry(java.lang.String)
   */
  @Override
  public List<Employee> findAllByCountry(String countryName){
    String query = "SELECT e from Employee e WHERE e.country.mstCountry.countryName = ?";
    Boolean isAdmin = securityService.findLoggedInUserRole().equals(Constants.ROLE_ADMIN) ? true : false;
    long empID=-1;
    if(!isAdmin){
    UserProfile userProfile = userService.findByEmail(securityService.findLoggedInUsername());
    empID = Long.parseLong(userProfile.getEmpNumber());
    query = query + "AND e.empId = ?";
    }
    Query q = entityManager.createQuery(query);
    if(!isAdmin){
      q.setParameter(2,empID);
    }
    q.setParameter(1, countryName);
    List<Employee> e = q.getResultList();
    return e;
  }
}