package com.erai.enterpriseconnect.service;

import java.util.List;

import com.erai.enterpriseconnect.model.MasterClientType;
public interface MasterClientTypeService{
	List<MasterClientType> findAll();
	MasterClientType findByTypeId(long id);
}
