package com.erai.enterpriseconnect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erai.enterpriseconnect.model.MasterClientStatus;
import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.repository.MasterClientTypeRepository;
@Service
public class MasterClientTypeServiceImpl implements MasterClientTypeService {

	@Autowired
	MasterClientTypeRepository masterClientTypeRepository;
	@Override
	public List<MasterClientType> findAll() {
		return masterClientTypeRepository.findAll();
	}
	@Override
	public MasterClientType findByTypeId(long id) {
		MasterClientType masterClientType=masterClientTypeRepository.findByTypeId(id);
		return masterClientType != null ? masterClientType : null;
	}
	
}
