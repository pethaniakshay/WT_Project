package com.erai.enterpriseconnect.service;

import java.util.List;

import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterContractType;
public interface MasterContractTypeService{
	List<MasterContractType> findAll();
	MasterContractType findByContractId(long contractId);
	
}
