package com.erai.enterpriseconnect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erai.enterpriseconnect.model.MasterClientStatus;
import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterContractType;
import com.erai.enterpriseconnect.repository.MasterClientTypeRepository;
import com.erai.enterpriseconnect.repository.MasterContractTypeRepository;
@Service
public class MasterContractTypeServiceImpl implements MasterContractTypeService {

	@Autowired
	MasterContractTypeRepository masterContractTypeRepository;
	@Override
	public List<MasterContractType> findAll() {
		return masterContractTypeRepository.findAll();
	}
  @Override
  public MasterContractType findByContractId(long contractId) {
    // TODO Auto-generated method stub
    return masterContractTypeRepository.findByContractId(contractId);
  }
	
}
