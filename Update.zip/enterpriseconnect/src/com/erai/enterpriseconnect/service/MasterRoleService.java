package com.erai.enterpriseconnect.service;

import java.util.List;

import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterPaymentTerms;
import com.erai.enterpriseconnect.model.MasterRole;
public interface MasterRoleService{
	List<MasterRole> findAll();
	MasterRole findByRoleId(long roleId);
}
