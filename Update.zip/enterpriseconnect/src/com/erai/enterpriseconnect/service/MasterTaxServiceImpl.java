/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.MasterTax;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.repository.BillingsRepository;
import com.erai.enterpriseconnect.repository.MasterCountryRepository;
import com.erai.enterpriseconnect.repository.MasterTaxRepository;
import com.erai.enterpriseconnect.repository.RoleRepository;
import com.erai.enterpriseconnect.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * MasterCountryServiceImpl - Country Related details
 * @author anand
 *
 */
@Service
public class MasterTaxServiceImpl implements MasterTaxService {
    @Autowired
    private MasterTaxRepository masterTaxRepository;
    
    @Autowired
    private MasterCountryRepository masterCountryRepository;

    @Override
    public List<MasterTax> findAll() {
      // TODO Auto-generated method stub
      return masterTaxRepository.findAll();
    }
    
    @Override
    public List<MasterTax> findByMstCountry(MasterCountry masterCountry) {
      // TODO Auto-generated method stub
      return masterTaxRepository.findByMstCountry(masterCountry);
    }


}
