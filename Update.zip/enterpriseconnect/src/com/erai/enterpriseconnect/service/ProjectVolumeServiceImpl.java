package com.erai.enterpriseconnect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erai.enterpriseconnect.model.MasterClientStatus;
import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterPaymentTerms;
import com.erai.enterpriseconnect.model.ProjectVolume;
import com.erai.enterpriseconnect.repository.MasterClientTypeRepository;
import com.erai.enterpriseconnect.repository.MasterPaymentTermsRepository;
import com.erai.enterpriseconnect.repository.ProjectVolumeRepository;
@Service
public class ProjectVolumeServiceImpl implements ProjectVolumeService {

	@Autowired
	ProjectVolumeRepository projectVolumeRepository;
	@Override
	public List<ProjectVolume> findAll() {
		return projectVolumeRepository.findAll();
	}
  @Override
  public ProjectVolume findByVolumeId(long id) {
    // TODO Auto-generated method stub
    return projectVolumeRepository.findByVolumeId( id);
  }
	
	
}
