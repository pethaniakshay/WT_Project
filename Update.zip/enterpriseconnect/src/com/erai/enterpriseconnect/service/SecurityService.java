/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

/**
 * Interface for security service
 * 
 * @author anand
 *
 */
public interface SecurityService {
  /**
   * @return username
   */
  String findLoggedInUsername();
  
  
  /**
   * @return username
   */
  String findLoggedInUserRole();

  /**
   * @param username
   * @param password
   */
  void autologin(String username, String password);
}
