package com.erai.enterpriseconnect.service;

import com.erai.enterpriseconnect.model.SystemSetting;

/**
 * Interface for System Setting Service
 * 
 * @author shailendra
 *
 */
public interface SystemSettingService {
  
 SystemSetting findAllSystemSetting();
 
 void save(SystemSetting systemSetting);
}
