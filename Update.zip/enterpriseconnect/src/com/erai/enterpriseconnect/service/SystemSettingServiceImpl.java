package com.erai.enterpriseconnect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erai.enterpriseconnect.model.SystemSetting;
import com.erai.enterpriseconnect.repository.SystemSettingRepository;

/**
 * SystemSettingServiceImpl - system setting  Related details
 * @author shailendra
 *
 */
@Service
public class SystemSettingServiceImpl implements SystemSettingService{

  @Autowired
  SystemSettingRepository systemSettingRepository;
  
  /**
   * Load all SystemSetting details
   * 
   * @param username
   * @return User Details
   */
  @Override
  public SystemSetting findAllSystemSetting() {
    List<SystemSetting> systemSettings = systemSettingRepository.findAll();
     return systemSettings.size()==0?null:systemSettings.get(0);
  }
  
  /**
   * save SystemSetting
   * 
   * @param username
   * @return User Details
   */
  @Override
  public void save(SystemSetting systemSetting) {
      systemSettingRepository.save(systemSetting);
  }
 
   

}
