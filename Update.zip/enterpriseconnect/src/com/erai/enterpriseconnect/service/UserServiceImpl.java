/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.core.util.DateUtil;
import com.erai.enterpriseconnect.model.Role;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.repository.RoleRepository;
import com.erai.enterpriseconnect.repository.UserRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * UserServiceImpl - User Related details
 * @author anand
 *
 */
@Service
public class UserServiceImpl implements UserService {
  private final Logger logger = LoggerFactory.getLogger(ProjectServiceImpl.class);
  
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Autowired
    private MasterRoleService masterRoleService;
    @Autowired
    private SecurityService securityService;
    
    @Autowired 
    private HttpSession httpSession;

    /* Save User Method
     * 
     * @param User user
     * @return
     */
    @Override
    public void save(UserProfile user) {
        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        user.setCreated_user((String)httpSession.getAttribute("username"));
        user.setUpdated_user((String)httpSession.getAttribute("username"));
        user.setCreated_date(DateUtil.getLocaleTime((String)httpSession.getAttribute("timezone")));
        user.setUpdated_date(DateUtil.getLocaleTime((String)httpSession.getAttribute("timezone")));
        //user.setRoles(new HashSet<>(roleRepository.findAll()));
        userRepository.save(user);
    }

    /* Find User by username
     * @param username string
     * @return User user
     */
    @Override
    public UserProfile findByEmail(String username) {
        return userRepository.findByEmail(username);
    }

    @Override
    public UserProfile changePassword(UserProfile user) {
      UserProfile existUser = userRepository.findByEmail(user.getEmail());
      existUser.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
      userRepository.save(existUser);
      return existUser;
    }

	@Override
	public List<UserProfile> findAll() {
		
		return userRepository.findAll();
	}

	@Override
	public UserProfile findOne(Long id) {
		UserProfile userProfile=userRepository.findOne(id);
		return userProfile!=null ? userProfile:null;
	}

  @Override
  public Map<String, Object> initUser() {
    Map<String, Object> userView = new HashMap<String, Object>();
    userView.put("roles", masterRoleService.findAll());
    Long id = findTopByOrderByUserProfileIdDesc().getUserProfileId() + 1;
    userView.put("roles", masterRoleService.findAll());
    userView.put("empNumber", id);
    return userView;
  }

  @Override
  public UserProfile findTopByOrderByUserProfileIdDesc() {
    // TODO Auto-generated method stub
    return userRepository.findTopByOrderByUserProfileIdDesc();
  }

  @Override
  public void saveUser(UserProfile user, HttpServletRequest request) {
    long id = findTopByOrderByUserProfileIdDesc().getUserProfileId() + 1;
    Long roleId = Long.parseLong(request.getParameter("role"));
    user.setMasterRole(masterRoleService.findByRoleId(roleId));
    Role role = roleRepository.findById(Constants.ROLE_USER_ID);
    user.setTimeZone(request.getParameter("timezone"));
    user.setRoles(new HashSet<Role>(Arrays.asList(role)));
    user.setUserProfileId(id);
    save(user);
  }
}
