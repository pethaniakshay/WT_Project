package com.erai.enterpriseconnect.service.mail;



import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;


/**
 * This class is for sending email.
 * @author user
 *
 */
@Service
public class SendEmailService {
  private MailSender mailSender;
  
  @Value("${email.sender}")
  private String sender;

  public void setMailSender(MailSender mailSender) {
    this.mailSender = mailSender;
  }

  /**
   *  Send mail
   * @param to
   * @param text
   * @param subject
   */
  public void sendMail(String to, String text, String subject) {
    SimpleMailMessage message = new SimpleMailMessage();
    message.setFrom(sender);
    message.setTo(to);
    message.setSubject(subject);
    message.setText(text);
    // sending message
    mailSender.send(message);
  }

}
