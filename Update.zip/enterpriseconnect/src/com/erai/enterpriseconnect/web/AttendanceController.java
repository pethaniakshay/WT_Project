/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * Created on : 14-8-2017
 * Author     : Akshay pethani
 * Version    : 1.0
 */
package com.erai.enterpriseconnect.web;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.core.util.VelocityUtil;
import com.erai.enterpriseconnect.display.EmployeeDisplay;
import com.erai.enterpriseconnect.model.Attendance;
import com.erai.enterpriseconnect.model.Employee;
import com.erai.enterpriseconnect.repository.CountryRepository;
import com.erai.enterpriseconnect.service.AttendanceService;
import com.erai.enterpriseconnect.service.BankProfileService;
import com.erai.enterpriseconnect.service.ClientProfileService;
import com.erai.enterpriseconnect.service.CurrencyExchangeService;
import com.erai.enterpriseconnect.service.EmployeeService;
import com.erai.enterpriseconnect.service.FinancialYearService;
import com.erai.enterpriseconnect.service.ProjectService;
import com.erai.enterpriseconnect.service.SecurityService;
import com.erai.enterpriseconnect.service.UserService;
import com.erai.enterpriseconnect.validator.ProjectValidator;
import com.erai.enterpriseconnect.validator.UserValidator;

/**
 * Controller Class for Attendance module
 * @author Akshay Pethani
 */
@Controller
@RequestMapping(value = "/attendance")
public class AttendanceController {

  private final Logger logger = LoggerFactory.getLogger(AttendanceController.class);
  @Autowired
  private UserService userService;

  @Autowired
  private AttendanceService attendanceService;

  @Autowired
  private SecurityService securityService;

  @Autowired
  private UserValidator userValidator;

  @Autowired
  private MessageSource messageSource;

  @Autowired
  BankProfileService bankService;

  @Autowired
  FinancialYearService financialYearService;

  @Autowired
  CurrencyExchangeService currencyExchangeService;

  @Autowired
  CountryRepository countryService;

  @Autowired
  UserService userProfile;

  @Autowired
  private EmployeeService employeeService;

  @Autowired
  ProjectService projectService;

  @Autowired
  ClientProfileService clientProfileService;

  @Autowired
  private ProjectValidator projectValidator;

  @Autowired
  private VelocityUtil velocityUtil;

  @Autowired
  private ServletContext serContext;

  @Value("${application.dateFormat}")
  private String dateFormat;

  @Value("${application.timeFormat}")
  private String timeFormat;

  /**
   * @param binder
   * @throws Exception
   */
  @InitBinder
  protected void initBinder(WebDataBinder binder) throws Exception {
    SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.APP_DATE_FORMAT);
    CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
    binder.registerCustomEditor(Date.class, editor);
  }

  /**
   * @param attendance
   * @param result
   * @param model
   * @return
   */
  @RequestMapping(value = "/", method = RequestMethod.GET)
  public String listView(@ModelAttribute Attendance attendance, BindingResult result, Model model) {
    logger.debug("Start Attendnace List View ");
    Locale locale = LocaleContextHolder.getLocale();
    model.addAttribute("isEmployeeConnect", "true");
    Boolean isAdmin = securityService.findLoggedInUserRole().equals(Constants.ROLE_ADMIN) ? true : false;
    logger.debug("Is Admin:" + isAdmin);
    model.addAttribute("isAdmin", isAdmin);
    if(!isAdmin){
      model.addAttribute("empCountry",attendanceService.getEmployeeCountryName());
    }
    Map<String, Object> attendanceValues = attendanceService.listUsers();
    model.addAttribute("attendanceList", attendanceValues.get("attendance"));
    model.addAttribute("year", attendanceValues.get("year"));
    model.addAttribute("countryList", attendanceValues.get("countryList"));
    model.addAttribute("language", Constants.localMap.get(locale.getLanguage()));
    //return "attendance_lv";
    return "TableditTest";
    //return "ted";
  }


  /**
   * @param model
   * @return
   */
  @RequestMapping(value = "/searchRecord", method = RequestMethod.GET)
  public String searchRecord(Model model) {
    logger.debug("In search Attendance");
    Locale locale = LocaleContextHolder.getLocale();
    model.addAttribute("language", Constants.localMap.get(locale.getLanguage()));
    model.addAttribute("isEmployeeConnect", "true");
    Boolean isAdmin = securityService.findLoggedInUserRole().equals(Constants.ROLE_ADMIN) ? true : false;
    logger.debug("Is Admin:" + isAdmin);
    model.addAttribute("isAdmin", isAdmin);
    if(!isAdmin){
      model.addAttribute("empCountry",attendanceService.getEmployeeCountryName());
    }
    Map<String, Object> attendanceSearchValues = attendanceService.search();
    model.addAttribute("countryList", attendanceSearchValues.get("countryList"));
    model.addAttribute("employees",attendanceSearchValues.get("employeeList"));
    return "attendance_search";
  };

  /**
   * @param country
   * @param year
   * @param month
   * @param pageSize
   * @return
   */
  @RequestMapping(value = "/search", method = RequestMethod.POST)
  @ResponseBody
  public String search(@RequestParam String country, @RequestParam String year, @RequestParam String month, @RequestParam String pageSize) {
    logger.debug("start search action");
    String data = "error";
    String role = securityService.findLoggedInUserRole();
    logger.debug("country:" + country);
    List<Attendance> attendanceList = attendanceService.searchAttendanceList(year, country, month, role);
    SimpleDateFormat sd = new SimpleDateFormat(dateFormat);
    SimpleDateFormat tf = new SimpleDateFormat(timeFormat);
    int serialNumber = 0;
    for (Attendance att : attendanceList) {
      att.setFormattedAttDate(sd.format(att.getAttDate()));
      att.setFormattedInTime(tf.format(att.getInTime()));
      att.setFormattedOutTime(tf.format(att.getOutTime()));
      att.setserialNumber(++serialNumber);
    }
    try {
      int pageSizeInt = Integer.parseInt(pageSize);
      Template template = velocityUtil.getTemplate("templates/attendance_lv.vm");
      VelocityContext context = new VelocityContext();
      context.put("attendance", attendanceList);
      Boolean isAdmin = securityService.findLoggedInUserRole().equals(Constants.ROLE_ADMIN) ? true : false;
      logger.debug("Is Admin:" + isAdmin);
      context.put("isAdmin", isAdmin);
      context.put("lstSize", attendanceList.size());
      logger.debug("List Size: " + attendanceList.size());
      context.put("pageSize", pageSizeInt);
      context.put("quickEditIcon","<span class=\"fa fa-pencil-square-o\"></span>");
      context.put("contextPath", serContext.getContextPath());
      data = velocityUtil.getData(context, template);
      logger.debug(data);
    } catch (Exception e) {
      logger.error("Error :" + e);
    }
    return data;
  }

  /**
   * @param country
   * @param empId
   * @param fromDate
   * @param toDate
   * @return
   */
  @RequestMapping(value = "/searchAttAjax", method = RequestMethod.POST)
  @ResponseBody
  public String searchAttAjax(@RequestParam String country,
      @RequestParam String empId , @RequestParam String fromDate,
      @RequestParam String toDate) {
    String data = "error";
    logger.debug("start searchAttAjax action");
    Date sFromDate = null;
    Date sToDate = null;
    try {
      sFromDate=new SimpleDateFormat("MM/dd/yyyy").parse(fromDate);
      sToDate=new SimpleDateFormat("MM/dd/yyyy").parse(toDate);
    } catch (ParseException e) {
      e.printStackTrace();
    }
    List<Attendance> attendanceList =attendanceService.searchAttListAjax(country,empId,sFromDate,sToDate);
    SimpleDateFormat sd = new SimpleDateFormat(dateFormat);
    SimpleDateFormat tf = new SimpleDateFormat(timeFormat);
    int serialNumber = 0;
    for (Attendance att : attendanceList) {
      att.setFormattedAttDate(sd.format(att.getAttDate()));
      att.setFormattedInTime(tf.format(att.getInTime()));
      att.setFormattedOutTime(tf.format(att.getOutTime()));
      att.setserialNumber(++serialNumber);
    }
    try {
      Template template = velocityUtil.getTemplate("templates/attendance_search.vm");
      VelocityContext context = new VelocityContext();
      context.put("attendance", attendanceList);
      Boolean isAdmin = securityService.findLoggedInUserRole().equals(Constants.ROLE_ADMIN) ? true : false;
      logger.debug("Is Admin:" + isAdmin);
      context.put("isAdmin", isAdmin);
      context.put("lstSize", attendanceList.size());
      logger.debug("List Size: " + attendanceList.size());
      context.put("quickEditIcon","<span class=\"fa fa-pencil-square-o\"></span>");
      context.put("contextPath", serContext.getContextPath());
      data = velocityUtil.getData(context, template);
      logger.debug(data);
    } catch (Exception e) {
      logger.error("Error :" + e);
    }
    logger.debug(data);
    return data;
  }

  /**
   * @param countryName
   * @return
   */
  @RequestMapping(value = "/countryEmpList", method = RequestMethod.POST)
  @ResponseBody
  @Transactional
  public List<EmployeeDisplay> countryEmpList(@RequestParam String countryName){
    logger.debug("*** Country Name: "+ countryName);
    List<Employee> employeeByCountry = employeeService.findAllByCountry(countryName);
    List<EmployeeDisplay> empDisplay = new ArrayList<EmployeeDisplay>();
    for(Employee emp : employeeByCountry){
      EmployeeDisplay  employeeDisplay = new EmployeeDisplay();
      employeeDisplay.setEmpId(emp.getEmpId());
      employeeDisplay.setEmpName(emp.getEmpName());
      empDisplay.add(employeeDisplay);
    }
    return empDisplay;
  }

  @RequestMapping(value = "/edit", method = RequestMethod.POST)
  @ResponseStatus(value = HttpStatus.OK)
  public void updateDataThatDoesntRequireClientToBeNotified(@RequestParam String action,String intm, String outtm, String no, String remarks) {
      logger.debug("******No: " + no);
      logger.debug("******IT: " + intm);
      logger.debug("******IT: " + outtm);
      logger.debug("******Name: " + action);
      attendanceService.editAttendance(action, no, intm, outtm, remarks);
  }
}