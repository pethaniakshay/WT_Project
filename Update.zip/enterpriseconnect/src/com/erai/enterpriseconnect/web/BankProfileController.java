/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 30-11-2016
 * Author     : Warun
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.web;


import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.erai.enterpriseconnect.model.BankProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.CurrencyExchange;
import com.erai.enterpriseconnect.model.FinancialYear;
import com.erai.enterpriseconnect.model.MasterAccountType;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.service.BankProfileService;
import com.erai.enterpriseconnect.service.CurrencyExchangeService;
import com.erai.enterpriseconnect.service.FinancialYearService;
import com.erai.enterpriseconnect.service.SecurityService;
import com.erai.enterpriseconnect.service.UserService;
import com.erai.enterpriseconnect.validator.UserValidator;

/**
 * SalesConnect controller for sales connect
 * 
 * @author Warun
 *
 */
@Controller
public class BankProfileController {
	
	private final Logger logger = LoggerFactory.getLogger(BankProfileController.class);
    @Autowired
    private UserService userService;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private UserValidator userValidator;
    
    @Autowired
    private MessageSource messageSource;
    
    @Autowired
    BankProfileService bankService;
    
    @Autowired
    FinancialYearService financialYearService;
    
    @Autowired
    CurrencyExchangeService currencyExchangeService;
    
     
    /**
     * Sample method in skeleton - needs modification
     * 
     * @param model
     * @return
     */
    @RequestMapping(value = "/bank_profile", method = RequestMethod.GET)
    public String home(Model model) {
      model.addAttribute("isSalesconnect","true");
        return "setting_bp";
    }
    
//    Add the new bank
    @RequestMapping(value = "/bank_profile_add", method = RequestMethod.POST,consumes = "application/json", produces = "application/json")
    public @ResponseBody String addNewBank(@RequestBody String jsonRecieve)throws Exception{
    	JSONException ee=new JSONException("Failed");
    	logger.info("\t mapping bank_profile_add");
    	JSONArray jsonArray=new JSONArray(jsonRecieve);
    	JSONObject jsonObj=new JSONObject();
    	jsonObj=jsonArray.getJSONObject(0);
    	BankProfile modelObj= new BankProfile();
    	Country country=new Country();
    	MasterAccountType accountType=new MasterAccountType();
    	accountType.setMstAccId(jsonObj.getLong("account_type"));
    	
    	modelObj.setBankName(jsonObj.getString("bank_name"));
    	country.setCountryId(jsonObj.getLong("country"));
    	modelObj.setCountry(country);
    	modelObj.setBranchName(jsonObj.getString("branch_name"));
    	modelObj.setSwiftCode(jsonObj.getString("swift_code"));
    	//modelObj.setAccountType(accountType);
    	modelObj.setAccountNo(jsonObj.getString("account_no"));
    	modelObj.setAccountName(jsonObj.getString("account_name"));
    	modelObj.setBankAddress(jsonObj.getString("bank_address"));
    	bankService.addBank(modelObj);
    	
	 return jsonObj.toString();	
    }
    
//  Update bank Profile
  @RequestMapping(value = "/bank_profile_update", method = RequestMethod.POST,consumes = "application/json", produces = "application/json")
  public @ResponseBody String updateBank(@RequestBody String jsonRecieve)throws Exception{
  	logger.info("\t bank_profile_update");
  	JSONArray jsonArray=new JSONArray(jsonRecieve);
  	JSONObject jsonObj=new JSONObject();
  	jsonObj=jsonArray.getJSONObject(0);
  	BankProfile modelObj= new BankProfile();
  	Country country=new Country();
  	MasterAccountType accountType=new MasterAccountType();
  	accountType.setMstAccId(jsonObj.getLong("account_type"));
  	
  	modelObj.setBankName(jsonObj.getString("bank_name"));
  	country.setCountryId(jsonObj.getLong("country"));
  	modelObj.setCountry(country);
  	modelObj.setBranchName(jsonObj.getString("branch_name"));
  	modelObj.setSwiftCode(jsonObj.getString("swift_code"));
  	//modelObj.setAccountType(accountType);
  	modelObj.setAccountNo(jsonObj.getString("account_no"));
  	modelObj.setAccountName(jsonObj.getString("account_name"));
  	modelObj.setBankAddress(jsonObj.getString("bank_address"));
  	modelObj.setBankId(jsonObj.getLong("bank_id"));
  	bankService.addBank(modelObj);
  	
	 return jsonObj.toString();	
  }
    
    
//    Show the list of all bank
    @RequestMapping(value = "/bank_profile_show", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody String showBankDetails()throws Exception{
    	logger.info("\t mapping bank_profile_show");
    	JSONObject jsonObj=new JSONObject();
		JSONArray jsonArrayBank=new JSONArray();
		JSONArray jsonArrayCountry=new JSONArray();
		JSONArray jsonArrayAccountType=new JSONArray();
		JSONArray jsonArrayCurrencyExchageRate=new JSONArray();
		JSONArray jsonArrayFinancialYear=new JSONArray();
    	List<BankProfile> bankProfileList=bankService.findAll();
    	List<MasterAccountType> accountTypeList=bankService.findAllAccountType();
    	List<MasterCountry> countryList=bankService.findAllCountry();
    	List<FinancialYear> financialYearList=financialYearService.findAll();
    	List<CurrencyExchange> currencyExchangeList=bankService.findAllCurrencyExchangeRate();
    	
    	
    	for(FinancialYear financialYear: financialYearList){
    		JSONObject json=new JSONObject();
    		json.put("financial_year_id", financialYear.getFinancialYearId());
    		json.put("financial_year", financialYear.getFinancialYear());
    		jsonArrayFinancialYear.put(json);
    	}
    	
    	for(MasterCountry country: countryList){
    		JSONObject json=new JSONObject();
    		json.put("country_id", country.getMstCountryId());
    		json.put("country_name", country.getCountryName());
    		jsonArrayCountry.put(json);
    	}
    	for(MasterAccountType accountType: accountTypeList){
    		JSONObject json=new JSONObject();
    		json.put("account_id", accountType.getMstAccId());
    		json.put("account_type", accountType.getAccType());
    		jsonArrayAccountType.put(json);
    	}
    	
    	
    	for(BankProfile bankProfile: bankProfileList){
    		JSONObject json=new JSONObject();
    		json.put("bank_name", bankProfile.getBankName());
    		json.put("bank_id", bankProfile.getBankId());
    		json.put("bank_country", bankProfile.getCountry().getCountryId());
    		
    		json.put("branch_name", bankProfile.getBranchName());
    		//json.put("account_type", bankProfile.getAccountType().getAccType());
    		json.put("account_no", bankProfile.getAccountNo());
    		json.put("account_name", bankProfile.getAccountName());
    		json.put("country_name", bankProfile.getCountry().getMstCountry().getCountryName());
    		json.put("swift_code", bankProfile.getSwiftCode());
    		json.put("address", bankProfile.getBankAddress());
    		jsonArrayBank.put(json);
    		
    	}
    	
    	for(CurrencyExchange currencyExchange: currencyExchangeList){
    		JSONObject json=new JSONObject();
    		json.put("currency_exchange_id", String.valueOf(currencyExchange.getCurrencyExchangeId()));
    		json.put("currency_exchange_year", currencyExchange.getFinancialYear().getFinancialYear());
    		json.put("usd", currencyExchange.getUsd());
    		json.put("jpy", currencyExchange.getJpy());
    		json.put("inr", currencyExchange.getInr());
    		jsonArrayCurrencyExchageRate.put(json);
    	}
    	
    	jsonObj.put("countryList", jsonArrayCountry);
    	jsonObj.put("accountTypeList", jsonArrayAccountType);
    	jsonObj.put("bankList", jsonArrayBank);
    	jsonObj.put("currencyExchangeList", jsonArrayCurrencyExchageRate);
    	jsonObj.put("financialYearList", jsonArrayFinancialYear);
    	
	 return jsonObj.toString();	
    }
    
//    add New Currency Exchange Rate
    @RequestMapping(value = "/currency_exchange_add", method = RequestMethod.POST,consumes = "application/json", produces = "application/json")
    public @ResponseBody String addNewCurrencyExchange(@RequestBody String jsonRecieve)throws Exception{
    	logger.info("\t mapping currency_exchange_add");
    	JSONArray jsonArray=new JSONArray(jsonRecieve);
    	JSONObject jsonObj=new JSONObject();
    	jsonObj=jsonArray.getJSONObject(0);
    	CurrencyExchange modelObj= new CurrencyExchange();
    	FinancialYear financialYear=new FinancialYear();
    	financialYear.setFinancialYearId(Long.parseLong(jsonObj.getString("financial_year")));
    	modelObj.setFinancialYear(financialYear);
    	modelObj.setUsd(jsonObj.getString("add_usd"));
    	modelObj.setJpy(jsonObj.getString("add_jpy"));
    	modelObj.setInr(jsonObj.getString("add_inr"));
    
    	currencyExchangeService.addCurrencyExchange(modelObj);
    	
	 return jsonObj.toString();	
    }
    
    @RequestMapping(value = "/edit_currency_exchange_edit", method = RequestMethod.POST,consumes = "application/json", produces = "application/json")
    public @ResponseBody String editCurrencyExchage(@RequestBody String jsonRecieve)throws Exception{
    	logger.info("\t mapping edit_currency_exchange_edit");
    	JSONArray jsonArray=new JSONArray(jsonRecieve);
    	List<JSONObject> objList=new ArrayList<JSONObject> ();
    	List<CurrencyExchange> modelList=new ArrayList<CurrencyExchange> ();
    	for(int i=0;i<jsonArray.length();i++){
    		JSONObject jsonObj=jsonArray.getJSONObject(i);
    		CurrencyExchange currencyExchange=new CurrencyExchange();
    		FinancialYear fYear=financialYearService.findByFinancialYear(jsonObj.getString("year"));
    		currencyExchange.setFinancialYear(fYear);
    		currencyExchange.setUsd(jsonObj.getString("usd"));
    		currencyExchange.setJpy(jsonObj.getString("jpy"));
    		currencyExchange.setInr(jsonObj.getString("inr"));
    		currencyExchange.setCurrencyExchangeId(jsonObj.getLong("currency_exchange_id"));
    		modelList.add(currencyExchange);
    		currencyExchangeService.updateCurrencyExchange(currencyExchange);
    	}
    	currencyExchangeService.save(modelList);
    	
	 return objList.toString();	
    }
    
}
