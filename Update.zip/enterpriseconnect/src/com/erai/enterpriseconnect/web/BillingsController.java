/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.web;

import java.io.File;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.core.util.EncrptBean;
import com.erai.enterpriseconnect.core.util.RequestUtil;
import com.erai.enterpriseconnect.core.util.VelocityUtil;
import com.erai.enterpriseconnect.display.ClientDisplay;
import com.erai.enterpriseconnect.display.CountryDisplay;
import com.erai.enterpriseconnect.display.EstimationDisplay;
import com.erai.enterpriseconnect.display.ProjectDisplay;
import com.erai.enterpriseconnect.display.WorkDataDisplay;
import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.Invoice;
import com.erai.enterpriseconnect.model.Project;
import com.erai.enterpriseconnect.model.WorkData;
import com.erai.enterpriseconnect.service.BillingsService;
import com.erai.enterpriseconnect.service.ClientProfileService;
import com.erai.enterpriseconnect.service.CountryService;
import com.erai.enterpriseconnect.service.InvoiceService;
import com.erai.enterpriseconnect.service.MasterTaxService;
import com.erai.enterpriseconnect.service.ProjectService;
import com.erai.enterpriseconnect.service.SecurityService;
import com.erai.enterpriseconnect.service.UserService;
import com.erai.enterpriseconnect.validator.EstimationValidator;
import com.erai.enterpriseconnect.validator.UserValidator;

/**
 * SalesConnect controller for sales connect
 * 
 * @author anand
 *
 */
@Controller
@RequestMapping(value = "/billingestimates")
public class BillingsController {

  private final Logger logger = LoggerFactory.getLogger(BillingsController.class);

  @Autowired
  private EstimationValidator estimationValidator;
  
  @Autowired
  private InvoiceService invoiceService;
  
  @Autowired
  private ServletContext serContext;

  @Autowired
  private BillingsService billingsService;

  @Autowired
  private UserService userService;
  
  @Autowired
  private ProjectService projectService;
  
  @Autowired
  private CountryService countryService;

  @Autowired
  private SecurityService securityService;
  
  @Autowired
  private MasterTaxService masterTaxService;

  @Autowired
  private ClientProfileService clientProfileService;
  
  @Autowired
  private UserValidator userValidator;

  @Autowired
  private MessageSource messageSource;

  @Autowired
  private VelocityUtil velocityUtil;
  
  @Value("${application.dateFormat}")
  private String dateFormat;

  /**
   * Sample method in skeleton - needs modification
   * 
   * @param model
   * @return
   */
  @RequestMapping(value = "/", method = RequestMethod.GET)
  public String list(Model model) {
    Locale locale = LocaleContextHolder.getLocale();
    model.addAttribute("isSalesconnect", "true");
    Map<String, Object> estValues = billingsService.listEstimation();
    // Values to view
    model.addAttribute("estimations", estValues.get("estimations"));
    model.addAttribute("year", estValues.get("year"));
    model.addAttribute("countryList", estValues.get("countryList"));
    model.addAttribute("language", Constants.localMap.get(locale.getLanguage()));
    return "billings_list";
  }

  /**
   * Sample method in skeleton - needs modification
   * 
   * @param model
   * @return
   */
  @RequestMapping(value = "/create", method = RequestMethod.GET)
  public String create(Model model) {
    model.addAttribute("isSalesconnect", "true");
    Estimation est = null;
    if(model.asMap().get("estimation")!= null){
      est = (Estimation) model.asMap().get("estimation");
    } else {
      est = new Estimation();
    }
    // Error Handling
    if(model.asMap().get("error")!= null){
      logger.debug("error:" + model.asMap().get("error"));
      model.addAttribute("error", model.asMap().get("error"));
    }
    // Business Logic
    Map<String, Object> estValues = billingsService.createEstimation(est);
    
    // Setting values to view
    model.addAttribute("clients", estValues.get("clients"));
    model.addAttribute("contractTypes", estValues.get("contractTypes"));
    model.addAttribute("paymentTerms", estValues.get("paymentTerms"));
    model.addAttribute("projects", estValues.get("projects"));
    model.addAttribute("projectVolumes", estValues.get("projectVolumes"));
    model.addAttribute("countries",estValues.get("countries") );
    model.addAttribute("defaultCountry",estValues.get("defaultCountry") );
    model.addAttribute("defaultCurrency",estValues.get("defaultCurrency"));
    model.addAttribute("estimation", est);
    model.addAttribute("taxList", estValues.get("taxList"));
    return "billings_est_create";
  }

  /**
   * Sample method in skeleton - needs modification
   * 
   * @param model
   * @return
   */
  @RequestMapping(value = "/viewRecord/{id}", method = RequestMethod.GET)
  public String viewRecord(@PathVariable("id") String id, Model model) {
    model.addAttribute("isSalesconnect", "true");
    logger.debug("inside view");
    // Business Logic -URL parameter is encrypted to avoid tampering
    id = EncrptBean.decrypt(id);
    logger.debug("decrypted id :" + id);
    Estimation est = billingsService.findById(id);
    Map<String, Object> estView = billingsService.viewEstimation(est);

    // Display Logic
    model.addAttribute("estimation", estView.get("estimation"));
    model.addAttribute("countryList", estView.get("countryList"));
    model.addAttribute("mgmtData", estView.get("mgmtData"));
    model.addAttribute("taxPercent", estView.get("taxPercent"));
    model.addAttribute("subTotal", estView.get("subTotal"));
    model.addAttribute("tax", estView.get("tax"));
    model.addAttribute("total", estView.get("total"));
    model.addAttribute("defaultCurrency",estView.get("defaultCurrency"));
    model.addAttribute("defaultCountry",estView.get("defaultCountry"));
    
    return "billings_est_viewRecord";
  }
  /**
   * Sample method in skeleton - needs modification
   * 
   * @param model
   * @return
   */
  @RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
  public String edit(@PathVariable("id") String id, Model model) {
    model.addAttribute("isSalesconnect", "true");
    model.addAttribute("isEdit", "true");
    Estimation est = billingsService.findById(id);
    Map<String, Object> estValues = billingsService.viewEstimation(est);
    Map<String, Object> estCreate = billingsService.createEstimation(est);
    estValues.putAll(estCreate);
    model.addAttribute("estimation", estValues.get("estimation"));
    model.addAttribute("countryList", estValues.get("countryList"));
    model.addAttribute("subTotal", estValues.get("subTotal"));
    model.addAttribute("tax", estValues.get("tax"));
    model.addAttribute("total", estValues.get("total"));
    model.addAttribute("clients", estValues.get("clients"));
    model.addAttribute("contractTypes", estValues.get("contractTypes"));
    model.addAttribute("paymentTerms", estValues.get("paymentTerms"));
    model.addAttribute("projects", estValues.get("projects"));
    model.addAttribute("projectVolumes", estValues.get("projectVolumes"));
    model.addAttribute("countries",estValues.get("countries") );
    model.addAttribute("defaultCurrency",estValues.get("defaultCurrency"));
    model.addAttribute("defaultCountry",estValues.get("defaultCountry"));
    model.addAttribute("mgmtData",estValues.get("mgmtData"));
    model.addAttribute("taxPercent",estValues.get("taxPercent"));
    model.addAttribute("taxList", estValues.get("taxList"));
    return "billings_est_create";
  }
  /**
   * Sample method in skeleton - needs modification
   * 
   * @param model
   * @return
   */
  @RequestMapping(value = "/save", method = RequestMethod.POST)
  public String save(Model model,
      @ModelAttribute("estimation") Estimation estimation,
      BindingResult bindingResult, RedirectAttributes attr,HttpServletRequest request) {
    logger.debug("save method starts:");
    estimationValidator.validate(estimation, bindingResult);
    if (bindingResult.hasErrors()) {
      logger.error("Error : " + bindingResult.getAllErrors().get(0));
      attr.addFlashAttribute("org.springframework.validation.BindingResult.estimation", bindingResult);
      String[] args = {bindingResult.getAllErrors().get(0).toString()};
      attr.addFlashAttribute("error", messageSource.getMessage("MSGSE003",args,request.getLocale()));
      attr.addFlashAttribute("estimation", estimation);
      return "redirect:/billingestimates/create";
    }
    Set<WorkData> workDataSet = billingsService.getWorkData(request.getParameterMap());
    model.addAttribute("isSalesconnect", "true");
    String countryCode = request.getParameterMap().get("selectedCountry").length > 0 ? request.getParameterMap().get("selectedCountry")[0]:"";
    logger.info("Country :" + countryCode);
    if(workDataSet.size() == 0){
      attr.addFlashAttribute("error", messageSource.getMessage("MSGSE001",null,request.getLocale()));
      attr.addFlashAttribute("estimation", estimation);
      logger.debug("date:" + estimation.getDateOfIssue());
      return "redirect:/billingestimates/create";
    }
    billingsService.saveEstimation(workDataSet,estimation,countryCode);
    logger.info("Estimation is saved." + estimation);
    attr.addFlashAttribute("message", "MSGSE002");
    attr.addFlashAttribute("estId", estimation.getId());
    return "redirect:/billingestimates/";
  }

  @RequestMapping(value = "/update/{id}", method = RequestMethod.POST)
  public String update(@PathVariable("id") String id,Model model,
      @ModelAttribute("estimation") Estimation estimation,
      BindingResult bindingResult, RedirectAttributes attr,HttpServletRequest request) {
    logger.debug("update method starts:");
    Estimation est = billingsService.findById(id);
    estimationValidator.validate(estimation, bindingResult);
    if (bindingResult.hasErrors()) {
      logger.error("Error : " + bindingResult.getAllErrors().get(0));
      attr.addFlashAttribute("org.springframework.validation.BindingResult.estimation", bindingResult);
      attr.addFlashAttribute("estimation", estimation);
      return "redirect:/billingestimates/edit";
    }
    Set<WorkData> workDataSet = billingsService.getWorkData(request.getParameterMap());
    model.addAttribute("isSalesconnect", "true");
    if(workDataSet.size() == 0){
      attr.addFlashAttribute("error", "MSGSE001");
      attr.addFlashAttribute("estimation", estimation);
      logger.debug("date:" + estimation.getDateOfIssue());
      return "redirect:/billingestimates/edit/${estimation.id}";
    }
    String countryCode = request.getParameterMap().get("selectedCountry").length > 0 ? request.getParameterMap().get("selectedCountry")[0]:"";
    billingsService.updateEstimation(workDataSet, estimation, est, countryCode);
    return "redirect:/billingestimates/";
  }

  @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
  public String delete(@PathVariable("id") String id,Model model,
      @ModelAttribute("estimation") Estimation estimation,
      BindingResult bindingResult, RedirectAttributes attr,HttpServletRequest request) {
    logger.debug("delete method starts:");
    Estimation est = billingsService.findById(id);
    logger.info("Estimation is deleted :" + estimation);
    attr.addFlashAttribute("message", "MSGSE004");
    attr.addFlashAttribute("estId", id);
    billingsService.delete(est);
    return "redirect:/billingestimates/";
  }
  @RequestMapping(value = "/search", method = RequestMethod.POST)
  @ResponseBody
  public String search(@RequestParam String country, @RequestParam String year,
      @RequestParam String month, @RequestParam String pageSize) {
    logger.debug("start search action");
    Locale locale = LocaleContextHolder.getLocale();
    DecimalFormat df = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(locale));
    String data = "error";
    String role = securityService.findLoggedInUserRole();
    logger.debug("country:" + country);
    List<Estimation> estList = billingsService.searchEstList(year, country, month,role);
    SimpleDateFormat sd = new SimpleDateFormat(dateFormat);
    double sum = 0.0d;
    double balance = 0.0d;
    for(Estimation est : estList){
      List<Invoice> invList = invoiceService.findAllByEstimation(est);
      //String amnt = EncrptBean.decrypt(est.getEstimationAmount());
      String amnt = est.getEstimationAmount();
      double invBalance = 0.0d;
      if (invList.size() == 0) {
        invBalance = Double.parseDouble(amnt);
      } else {
        for (Invoice inv : invList) {
          double loopBal = Double.parseDouble(inv.getBalance());
          if (invBalance > loopBal) {
            invBalance = loopBal;
          }
        }
      }
      est.setBalance(df.format(invBalance));
      est.setEstimationAmount(df.format(Double.parseDouble(amnt)));
      est.setFormattedDate(sd.format(est.getDateOfIssue()));
      sum = sum + Double.parseDouble(amnt);
      balance = balance + invBalance;
    }
    try {
      int pageSizeInt = Integer.parseInt(pageSize);
      Template template = velocityUtil.getTemplate("templates/billing_est.vm");
      VelocityContext context = new VelocityContext();
      context.put("estimations", estList);
      Boolean isAdmin = securityService.findLoggedInUserRole().equals(Constants.ROLE_ADMIN)? true : false;
      context.put("currency",countryService.findByCountryName(country).getMstCountry().getCurrencySymbol());
      context.put("isAdmin", isAdmin);
      context.put("total", df.format(sum));
      context.put("balance", df.format(balance));
      context.put("lstSize", estList.size());
      context.put("pageSize", pageSizeInt);
      context.put("contextPath", serContext.getContextPath());
      data = velocityUtil.getData(context, template);
    } catch (Exception e) {
      logger.error("Error :" + e);
    }
    return data;
  }

  @RequestMapping(value = "/searchEstimates", method = RequestMethod.GET)
  public String searchEstimates(Model model) {
    model.addAttribute("isSalesconnect", "true");
    Locale locale = LocaleContextHolder.getLocale();
    Map<String, Object> estValues = billingsService.search();
    model.addAttribute("estimations", estValues.get("estimations"));
    model.addAttribute("userProfile", estValues.get("userProfile"));
    model.addAttribute("userProfiles", estValues.get("userProfiles"));
    model.addAttribute("clientProfiles", estValues.get("clientProfiles"));
    model.addAttribute("countryList", estValues.get("countryList"));
    model.addAttribute("year", estValues.get("year"));
    model.addAttribute("language", Constants.localMap.get(locale.getLanguage()));
    return "billings_est_search";
  }

  @RequestMapping(value = "/projectData", method = RequestMethod.POST)
  @ResponseBody
  public String search(@RequestParam String id) {
    logger.debug("start projectData ");
    String data = "";
    if(!StringUtils.isEmpty(id)){
    long projId = Long.parseLong(id);
    Project proj = projectService.findByProjectId(projId);
    if (proj != null) {
      data = new SimpleDateFormat("yyyy/MM/dd").format(proj.getStartDate())
          + ":" + new SimpleDateFormat("yyyy/MM/dd").format(proj.getEndDate());
    }
    }
    return data;
  }
  
  @RequestMapping(value = "/currencySymbol", method = RequestMethod.POST)
  @ResponseBody
  public CountryDisplay currencySymbol(@RequestParam String name) {
    logger.debug("start getCurrencySymbol ");
    CountryDisplay data = new CountryDisplay();
    Country country = countryService.findByCountryName(name);
    List<ClientProfile> clientProfile = clientProfileService.getClients(country);
    logger.debug("clientProfile " + clientProfile.size());
    List<ClientDisplay> clientDisplay = new ArrayList<ClientDisplay>();
    for(ClientProfile cp : clientProfileService.getClients(country)){
      ClientDisplay cd = new ClientDisplay();
      cd.setClientProfileId(cp.getClientProfileId());
      cd.setCompanyName(cp.getCompanyName());
      clientDisplay.add(cd);
    }
    if(country != null){
      data.setCurrencySymbol( country.getMstCountry().getCurrencySymbol());
      data.setTax(masterTaxService.findByMstCountry(country.getMstCountry()));
      data.setClientProfile(clientDisplay);
    }
    return data;
  }
  
  @RequestMapping(value = "/searchEstAjax", method = RequestMethod.POST)
  @ResponseBody
  public String searchEstAjax(@RequestParam String country,
      @RequestParam String year, @RequestParam String client,
      @RequestParam String user) {
    logger.debug("start searchEstAjax action");
    String data = "error";
    List<Estimation> estList = billingsService.searchEstListAjax(year, country, client, user);
    SimpleDateFormat sd = new SimpleDateFormat(dateFormat);
    double sum = 0.0d;
    for(Estimation est : estList){
      String amnt = est.getEstimationAmount();
      est.setEstimationAmount(amnt);
      est.setFormattedDate(sd.format(est.getDateOfIssue()));
      sum = sum + Double.parseDouble(amnt);
    }
    try {
      int yearInt = Integer.parseInt(year);
      String finYear = yearInt + "-" + ((yearInt + 1)+"").substring(2);
      Template template = velocityUtil.getTemplate("templates/billing_est_search.vm");
      VelocityContext context = new VelocityContext();
      context.put("estimations", estList);
      Boolean isAdmin = securityService.findLoggedInUserRole().equals(Constants.ROLE_ADMIN)? true : false;
      context.put("isAdmin", isAdmin);
      context.put("finYear", finYear);
      context.put("currency",countryService.findByCountryName(country).getMstCountry().getCurrencySymbol());
      context.put("total", String.format("%.2f", sum));
      context.put("lstSize", estList.size());
      data = velocityUtil.getData(context, template);
    } catch (Exception e) {
      logger.error("Error :" + e);
    }
    return data;
  }
  
  @RequestMapping(value = "/pdf/{id}", method = RequestMethod.GET)
  public void pdf(@PathVariable("id") String id, Model model, HttpServletRequest request, HttpServletResponse response) {
    Estimation est = billingsService.findById(id);
    String data = null;
    File logo = new File("resources/images/logo_red_transparent.png");
    if(! logo.exists()){
        logger.warn("File " + logo.getName() + " not exists");
        logger.debug("Real Path :" + serContext.getRealPath("resources/images/"));
    }
    double mgmtTax = 0.0;
    double tax = 0.0;
    Map<String,Object> pdfData = billingsService.viewEstimation(est);
    
    try {
      Template template = velocityUtil.getTemplate("templates/estimation_pdf.vm");
      VelocityContext vcontext = new VelocityContext();
      vcontext.put("est", est);
      vcontext.put("dateOfIssue", new SimpleDateFormat("yyyy/MM/dd").format(est.getDateOfIssue()));
      vcontext.put("dateOfValidity", new SimpleDateFormat("yyyy/MM/dd").format(est.getEstimationValidity()));
      vcontext.put("startDate", new SimpleDateFormat("yyyy/MM/dd").format(est.getProject().getStartDate()));
      vcontext.put("endDate", new SimpleDateFormat("yyyy/MM/dd").format(est.getProject().getEndDate()));
      if(pdfData.get("mgmtData")!= null){
        vcontext.put("mgmtData", ((WorkData) pdfData.get("mgmtData")));
      }
      vcontext.put("tax", pdfData.get("tax"));
      vcontext.put("taxPercent", pdfData.get("taxPercent"));
      vcontext.put("subTotal", pdfData.get("subTotal"));
      vcontext.put("total", pdfData.get("total"));
      vcontext.put("count", est.getWorkData().size());
      if(!pdfData.get("defaultCountry").equals("INDIA")){
      vcontext.put("defaultCurrency",  pdfData.get("defaultCurrency"));
      }
      data = velocityUtil.getData(vcontext, template);
      ITextRenderer renderer = new ITextRenderer();
      logger.debug("Base URL: " + RequestUtil.getBaseUrl(request));
      renderer.setDocumentFromString(data,RequestUtil.getBaseUrl(request)+"resources/images/");
      renderer.layout();
      OutputStream os =  response.getOutputStream();
      renderer.createPDF(os);
      os.close();
    } catch (Exception e) {
      logger.error("Error :" , e);
    }
  }
    @RequestMapping(value = "/createDuplicate/{id}", method = RequestMethod.GET)
    public String createDuplicate(@PathVariable("id") String id, Model model) {
      model.addAttribute("isSalesconnect", "true");
      model.addAttribute("isDuplicate", "true");
      Estimation est = billingsService.findById(id);
      Map<String, Object> estValues = billingsService.viewEstimation(est);
      Map<String, Object> estCreate = billingsService.createEstimation(est);
      estValues.putAll(estCreate);
      Estimation dummyEstimation = (Estimation) estValues.get("estimation");
      dummyEstimation.setId("");
      model.addAttribute("estimation", dummyEstimation);
      model.addAttribute("countryList", estValues.get("countryList"));
      model.addAttribute("subTotal", estValues.get("subTotal"));
      model.addAttribute("tax", estValues.get("tax"));
      model.addAttribute("total", estValues.get("total"));
      model.addAttribute("clients", estValues.get("clients"));
      model.addAttribute("contractTypes", estValues.get("contractTypes"));
      model.addAttribute("paymentTerms", estValues.get("paymentTerms"));
      model.addAttribute("projects", estValues.get("projects"));
      model.addAttribute("projectVolumes", estValues.get("projectVolumes"));
      model.addAttribute("countries",estValues.get("countries") );
      model.addAttribute("defaultCurrency",estValues.get("defaultCurrency"));
      model.addAttribute("defaultCountry",estValues.get("defaultCountry"));
      model.addAttribute("mgmtData",estValues.get("mgmtData"));
      model.addAttribute("taxPercent",estValues.get("taxPercent"));
      model.addAttribute("taxList", estValues.get("taxList"));
      model.addAttribute("estAmt",dummyEstimation.getEstimationAmount());
      return "billings_est_create";
    }
    @RequestMapping(value = "/estimationDetails", method = RequestMethod.POST)
    @ResponseBody
    public EstimationDisplay estimationDetails(@RequestParam String id) {
      logger.debug("start estimationDetails ");
      logger.debug("id " + id);
      Estimation estimation = billingsService.findById(id);
      logger.debug("workdata " + estimation.getWorkData());
      List<WorkDataDisplay> wkDisplay = new ArrayList<WorkDataDisplay>();
      for(WorkData w:estimation.getWorkData()){
        WorkDataDisplay wdd = new WorkDataDisplay();
        wdd.setParticular(w.getParticular());
        wdd.setDisplayOrder(w.getDisplayOrder());
        wdd.setNoOfResources(w.getNoOfResources());
        wdd.setRate(w.getRate());
        wdd.setManagementCost(w.getManagementCost());
        wdd.setProjectVolume(w.getProjectVolume());
        wdd.setIsWorkData(w.getIsWorkData());
        wdd.setTax(w.getTax());
        wkDisplay.add(wdd);
        
      }
      EstimationDisplay display = new EstimationDisplay();
      ProjectDisplay projDis = new ProjectDisplay();
      Project pj = estimation.getProject();
      // Project Display setting
      projDis.setProjectId(pj.getProjectId());
      projDis.setMasterContractTypeId(pj.getMasterContractType().getContractId()+"");
      SimpleDateFormat sd = new SimpleDateFormat(dateFormat);
      projDis.setStartDate(sd.format(pj.getStartDate()));
      projDis.setEndDate(sd.format(pj.getEndDate()));
      projDis.setProjectVol(pj.getProjectVol());
      
      display.setEstimationAmount(estimation.getEstimationAmount());
      display.setMasterPaymentTerms(estimation.getMasterPaymentTerms());
      display.setProject(projDis);
      display.setPoNumber(estimation.getPoNumber());
      display.setWorkData(wkDisplay);
      return display;
    }
  }
