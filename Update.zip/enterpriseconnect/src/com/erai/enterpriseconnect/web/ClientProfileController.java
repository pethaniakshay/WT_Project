package com.erai.enterpriseconnect.web;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.erai.enterpriseconnect.display.ClientDisplay;
import com.erai.enterpriseconnect.display.CountryDisplay;
import com.erai.enterpriseconnect.model.BankProfile;
import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterClientStatus;
import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.service.BankProfileService;
import com.erai.enterpriseconnect.service.BillingsService;
import com.erai.enterpriseconnect.service.ClientProfileService;
import com.erai.enterpriseconnect.service.CountryService;
import com.erai.enterpriseconnect.service.MasterClientStatusServiceImpl;
import com.erai.enterpriseconnect.service.MasterClientTypeService;
import com.erai.enterpriseconnect.service.MasterCountryService;
import com.erai.enterpriseconnect.service.UserService;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;

/**
 * Client Procontroller for sales connect
 * 
 * @author Bishunjay
 *
 */
@Controller
public class ClientProfileController {
  private final Logger logger = LoggerFactory
      .getLogger(SalesConnectController.class);
  @Autowired
  private MessageSource messageSource;

  @Autowired
  private ClientProfileService clientProfileService;
  
  @Autowired
  private BillingsService billingsService;

  @Autowired
  private MasterCountryService masterCountryService;

  @Autowired
  CountryService countryService;

  @Autowired
  MasterClientStatusServiceImpl masterClientStatusService;

  @Autowired
  MasterClientTypeService masterClientTypeService;

  @Autowired
  BankProfileService bankProfileService;

  @Autowired
  UserService userService;

  @RequestMapping(value = "/clientProfile", method = RequestMethod.GET)
  public String viewClientProfilePage(
      @ModelAttribute("command") ClientProfile clientProfile,
      BindingResult result, Model model) {
    logger.debug("viewClientProfilePage start");
    model.addAttribute("isClientProfileView", "true");
    String errorMsg = "";
    try {
      Map<String, Object> clientValues = clientProfileService.populateInitialData();
      model.addAttribute("isSalesconnect", "true");
      model.addAttribute("countryList", clientValues.get("countryList"));
      model.addAttribute("clientList", clientValues.get("clientList"));
      model.addAttribute("clientStatus", clientValues.get("clientStatus"));
      model.addAttribute("clientType", clientValues.get("clientType"));
      model.addAttribute("listBank", clientValues.get("listBank"));
      model.addAttribute("userList", clientValues.get("userList"));
    } catch (Exception e) {
      e.printStackTrace();
      errorMsg = "Client Data can't be loaded";
      model.addAttribute("errorMsg", errorMsg);
    }
    return "clientProfile";
  }

  @RequestMapping(value = "/clientProfileSave", method = RequestMethod.POST)
  public String clientProfileSave(
      @ModelAttribute("command") ClientProfile clientProfile,
      BindingResult result, Model model, HttpServletRequest request) {
    logger.debug("clientProfileSave start");
    String errorMsg = "";
    String successMsg = "";
    try {
      clientProfileService.saveClientProfileData(request, clientProfile);
      Map<String, Object> clientValues = clientProfileService.populateInitialData();
      model.addAttribute("isSalesconnect", "true");
      model.addAttribute("countryList", clientValues.get("countryList"));
      model.addAttribute("clientList", clientValues.get("clientList"));
      model.addAttribute("clientStatus", clientValues.get("clientStatus"));
      model.addAttribute("clientType", clientValues.get("clientType"));
      model.addAttribute("listBank", clientValues.get("listBank"));
      model.addAttribute("userList", clientValues.get("userList"));
      // ends code for repoulating the data to show in client profile pag
    } catch (Exception e) {
      errorMsg = "Please Recheck the data before Inserting";// temporary it will
      e.printStackTrace();
    }
    model.addAttribute("errorMsg", errorMsg);
    model.addAttribute("successMsg", successMsg);
    return "clientProfile";
  }

  // Controller for ajax calling

  @RequestMapping(value = "/selPayBankForCountry", method = RequestMethod.GET)
  @ResponseBody
  public String selPayBankForCountry(HttpServletRequest request) {
    System.out.println("countryID parameter: "
        + request.getParameter("countryId"));
    Long pssedCountryId = Long.parseLong(request.getParameter("countryId"));
    List<BankProfile> bankProfileList = bankProfileService.findAll();
    String selectedBanks = "";
    logger.info("bankProfileList : " + bankProfileList);
    for (BankProfile bankProfile : bankProfileList) {
      Long countryId = bankProfile.getCountry().getCountryId();
      System.out.println("countryId :" + countryId);
      if (countryId == pssedCountryId) {
        System.out.println("equal");
        if (!selectedBanks.equals("")) {
          selectedBanks = selectedBanks + "@,C" + bankProfile.getBankId()
              + "#:@$#" + bankProfile.getBankName();
        } else {
          selectedBanks = bankProfile.getBankId() + "#:@$#"
              + bankProfile.getBankName();
        }
      }
    }
    System.out.println("selectedBanks : " + selectedBanks);
    return selectedBanks;
  }

  @RequestMapping(value = "/selSalesPersonForCountry", method = RequestMethod.GET)
  @ResponseBody
  public String selSalesPersonForCountry(HttpServletRequest request) {
    System.out.println("countryID parameter: "
        + request.getParameter("countryId"));
    Long pssedCountryId = Long.parseLong(request.getParameter("countryId"));
    List<UserProfile> salsesPersonList = userService.findAll();
    String selectedSalesPersons = "";
    logger.info("salesPersonList : " + salsesPersonList);
    for (UserProfile userProfile : salsesPersonList) {

      Set<Country> countrySet = userProfile.getCountries();
      for (Country country : countrySet) {
        if (country.getCountryId() == pssedCountryId) {
          System.out.println("equal");
          if (!selectedSalesPersons.equals("")) {
            selectedSalesPersons = selectedSalesPersons + "@,C"
                + userProfile.getUserProfileId() + "#:@$#"
                + userProfile.getName();
          } else {
            selectedSalesPersons = userProfile.getUserProfileId() + "#:@$#"
                + userProfile.getName();
          }
        }
      }
    }
    return selectedSalesPersons;
  }
  
  @RequestMapping(value = "/clientDetails", method = RequestMethod.POST)
  @ResponseBody
  @Transactional
  public ClientDisplay clientDetails(@RequestParam String id) {
    logger.debug("start clientDetails ");
    ClientDisplay data = new ClientDisplay();
    logger.debug("id " + id);
    int clientProfileId = Integer.parseInt(id);
    ClientProfile clientProfile = clientProfileService.findByClientProfileId(clientProfileId);
    
    data.setClientProfileId(clientProfile.getClientProfileId());
    data.setClientType(clientProfile.getMasterClientype().getTypeName());
    data.setSalesInCharge(clientProfile.getUserProfile().getName());
    data.setCompanyName(clientProfile.getCompanyName());
    data.setTelephoneNo(clientProfile.getTelephoneNo());
    data.setAddress(clientProfile.getAddress());
    data.setZipCode(clientProfile.getZipCode());
    List<String> estId = new ArrayList<String>();
    List<Estimation> estList = billingsService.findAllByClientProfile(clientProfile);
    for(Estimation est: estList){
      estId.add(est.getId());
    }
    logger.debug("list: " + estList);
    data.setEstList(estId);
    return data;
  }
  
  @RequestMapping(value = "/countryClientlist", method = RequestMethod.POST)
  @ResponseBody
  @Transactional
  public List<ClientDisplay> countryClientlist(@RequestParam String countryName) {
    logger.debug("start countryClientlist ");
    List<ClientDisplay> cdList = new ArrayList<ClientDisplay>();
    logger.debug("country : " + countryName);
    MasterCountry masterCountry = masterCountryService.findByCountryName(countryName);
    Country country = countryService.findByMasterCountry(masterCountry);
    List<ClientProfile> clientProfileList = clientProfileService.findAllByCountry(country);
    
    for(ClientProfile clientProfile: clientProfileList){
      ClientDisplay data = new ClientDisplay();
      data.setClientProfileId(clientProfile.getClientProfileId());
      data.setCompanyName(clientProfile.getCompanyName());
      cdList.add(data);
    }
    logger.debug("cdList : " + cdList);
    return cdList;
  }
}
