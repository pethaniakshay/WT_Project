/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.web;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.support.RequestContextUtils;
import org.springframework.security.core.userdetails.UserDetails;

import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.service.SecurityService;
import com.erai.enterpriseconnect.service.UserService;
import com.erai.enterpriseconnect.validator.UserValidator;

/**
 * SalesConnect controller for sales connect
 * 
 * @author anand
 *
 */
@Controller
public class EmployeeConnectController {
	
	private final Logger logger = LoggerFactory.getLogger(EmployeeConnectController.class);
    @Autowired
    private UserService userService;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private UserValidator userValidator;
    
    @Autowired
    private MessageSource messageSource;

    /**
     * Sample method in skeleton - needs modification
     * 
     * @param model
     * @return
     */
    @RequestMapping(value = "/employeeConnect", method = RequestMethod.GET)
    public String home(Model model) {
      model.addAttribute("isEmployeeConnect","true");
        return "employee_home";
    }
}
