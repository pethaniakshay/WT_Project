/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 30-11-2016
 * Author     : Warun
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.web;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.erai.enterpriceconnect.exception.ERPBusinessException;
import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.display.ClientDisplay;
import com.erai.enterpriseconnect.display.ProjectDisplay;
import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.Project;
import com.erai.enterpriseconnect.model.Resource;
import com.erai.enterpriseconnect.model.WorkData;
import com.erai.enterpriseconnect.repository.CountryRepository;
import com.erai.enterpriseconnect.service.BankProfileService;
import com.erai.enterpriseconnect.service.ClientProfileService;
import com.erai.enterpriseconnect.service.CurrencyExchangeService;
import com.erai.enterpriseconnect.service.FinancialYearService;
import com.erai.enterpriseconnect.service.ProjectService;
import com.erai.enterpriseconnect.service.SecurityService;
import com.erai.enterpriseconnect.service.UserService;
import com.erai.enterpriseconnect.validator.EstimationValidator;
import com.erai.enterpriseconnect.validator.ProjectValidator;
import com.erai.enterpriseconnect.validator.UserValidator;

/**
 * SalesConnect controller for Project List View
 * 
 * @author Warun
 *
 */
@Controller
public class ProjectListViewController {
	
	private final Logger logger = LoggerFactory.getLogger(ProjectListViewController.class);
    @Autowired
    private UserService userService;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private UserValidator userValidator;
    
    @Autowired
    private MessageSource messageSource;
    
    @Autowired
    BankProfileService bankService;
    
    @Autowired
    FinancialYearService financialYearService;
    
    @Autowired
    CurrencyExchangeService currencyExchangeService;
    
    @Autowired
    CountryRepository countryService;
    
    @Autowired
    UserService userProfile;
    
    @Autowired
    ProjectService projectService;
    
    @Autowired
    ClientProfileService clientProfileService;
    
    @Autowired
    private ProjectValidator projectValidator;
    
    @Value("${application.dateFormat}")
    private String dateFormat;
    
    @InitBinder
    protected void initBinder(WebDataBinder binder) throws Exception {
      SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.APP_DATE_FORMAT);
      CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
      binder.registerCustomEditor(Date.class, editor);
    }
    /**
     * Sample method in skeleton - needs modification
     * 
     * @param model
     * @return
     */
    @RequestMapping(value = "/projectListView", method = RequestMethod.GET)
    public String listView(@ModelAttribute("command") Country country,BindingResult result, Model model) {
      
      model.addAttribute("isProject","true");
      List<Project> projectList=null;
      projectList=projectService.findAll();
      model.addAttribute("projectList", projectList);
      Map<String,Object> projView = projectService.initProject();
      model.addAttribute("project", projView.get("project"));
      model.addAttribute("clients", projView.get("clients"));
      model.addAttribute("countries", projView.get("countries"));
      model.addAttribute("contractTypes",  projView.get("contractTypes"));
      model.addAttribute("clientTypes", projView.get("clientTypes"));
      model.addAttribute("projectVolumes", projView.get("projectVolumes"));
      model.addAttribute("roles", projView.get("roles"));
      model.addAttribute("employees", projView.get("employees"));
      model.addAttribute("dateFormat", dateFormat);
      return "project_lv";
    }
    
    @RequestMapping(value = "/saveProject", method = RequestMethod.POST)
    public String saveProject(Model model,
        @ModelAttribute("project") Project project,
        BindingResult bindingResult, RedirectAttributes attr,HttpServletRequest request) {
      logger.debug("Project save method starts:");
      projectValidator.validate(project, bindingResult);
      if (bindingResult.hasErrors()) {
        logger.error("Error : " + bindingResult.getAllErrors().get(0));
        attr.addFlashAttribute("org.springframework.validation.BindingResult.project", bindingResult);
        attr.addFlashAttribute("project", project);
        return "redirect:/projectListView";
      }
      project = projectService.getProjectDetails(request, project);
      Set<Resource> resource = projectService.getResourceData(request.getParameterMap());
      if (resource.size() == 0) {
        if(project.getProjectId()!= 0){
          attr.addFlashAttribute("editError", "Project with code " + project.getProjectCode() + " is not updated");
        }
        return "redirect:/projectListView";
      }
      logger.debug("Project resources:" + project.getMasterContractType().getContractId());
      projectService.saveProject(project,resource);
      logger.info("Project is saved." + project);
      if( StringUtils.isEmpty(request.getParameter("projectId"))){
        attr.addFlashAttribute("message", "project.save");
      } else {
        attr.addFlashAttribute("editMessage", "project.update");
      }
      attr.addFlashAttribute("prjCode", project.getProjectCode());
      return "redirect:/projectListView";
    }
    
    @RequestMapping(value = "/projectDetails", method = RequestMethod.POST)
    @ResponseBody
    public List<ProjectDisplay> projectDetails(@RequestParam String id) {
      logger.debug("start projectDetails ");
      List<ProjectDisplay> data = new ArrayList<ProjectDisplay>();
      logger.debug("id " + id);
      int clientProfileId = Integer.parseInt(id);
      ClientProfile clientProfile = clientProfileService.findByClientProfileId(clientProfileId);
      List<Project> project = projectService.findAllByClientProfile(clientProfile);
      for(Project pr : project){
        ProjectDisplay pd = new ProjectDisplay();
        pd.setProjectId(pr.getProjectId());
        pd.setProjectName(pr.getProjectName());
        data.add(pd);
      }
      return data;
    }
    
}
