package com.erai.enterpriseconnect.web;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.erai.enterpriseconnect.model.SystemSetting;
import com.erai.enterpriseconnect.service.SystemSettingService;

/**
 * SystemSettingController for changing sales connect page color,background, footer text and image
 * @author user
 *
 */
@Controller
@SessionAttributes("systemSetting")
public class SystemSettingController {

  private final Logger logger = LoggerFactory
      .getLogger(SystemSettingController.class);

  @Autowired
  private SystemSettingService systemSettingService;

  @Autowired
  private ServletContext context;

  @Autowired
  private MessageSource messageSource;
  
  
  /**
   * action for display system page
   * @param request
   * @return
   */
  @RequestMapping("/systemSetting")
  public String showSystemSettingPage(Model model) {
    
    //logger.debug("start system setting Action");
    SystemSetting systemSetting = systemSettingService.findAllSystemSetting();
    model.addAttribute("systemSetting",systemSetting != null ? systemSetting : new SystemSetting());
    //logger.debug("exit system setting Action");
    return "setting_st";

  }
  
  /**
   * action for saving system setting
   * 
   * @param footerText
   * @param request
   * @return
   */
  @RequestMapping(value = "/saveSystemSetting", method = RequestMethod.POST)
  public String saveFooterText(Model model, @ModelAttribute("systemSetting") SystemSetting systemSetting) {
    
    logger.debug("start save system setting Action");
    systemSettingService.save(systemSetting);
    logger.debug("exit system setting Action");
    return "setting_st";

  }
  
  /**
   * upload image
   * 
   * @param model
   * @param image
   * @param request
   * @return
   */
  @RequestMapping(value = "/uploadDesktopImage", method = RequestMethod.POST)
  public String uploadDesktopImage(Model model,
      @RequestParam(value = "fileInput", required = false) MultipartFile image,@ModelAttribute("systemSetting") SystemSetting systemSetting) {
    
    logger.debug("upload desktop image system setting Action");
     String name = "";
    if (!image.isEmpty()) {
      try {
        name = image.getOriginalFilename();
        byte[] bytes = image.getBytes();
        String absoluteFilePath = context.getRealPath("/resources/images");

        File dir = new File(absoluteFilePath);
        if (!dir.exists())
          dir.mkdirs();

        // Create the file on server
        File serverFile = new File(dir.getAbsolutePath() + File.separator
            + name);
        BufferedOutputStream stream = new BufferedOutputStream(
            new FileOutputStream(serverFile));
        systemSetting.setBackgroundImagPath(name);
        stream.write(bytes);
        stream.close();

        logger.info("Server File Location=" + serverFile.getAbsolutePath());

        logger.debug("You successfully uploaded file=" + name);

        systemSettingService.save(systemSetting);
      } catch (Exception e) {
        logger.debug("You failed to upload " + name + " => " + e.getMessage());
      }
    } else {
      logger.debug("You failed to upload " + name
          + " because the file was empty.");
     }

    return "setting_st";

  }
  
  /**
   * action to find all system setting data
   * 
   * @return
   */
  @RequestMapping(value = "/getAllSystemSettings", method = RequestMethod.POST)
  public @ResponseBody String getAllSystemSettings() {
    //logger.debug("Start system setting Action");
    SystemSetting systemSetting = systemSettingService.findAllSystemSetting();
    JSONObject jsonObj = new JSONObject(systemSetting);
    //logger.info("Json value of system setting:" + jsonObj);
   // logger.debug("exit getAllSystemSettings Action");
    return jsonObj.toString();
  }

}
