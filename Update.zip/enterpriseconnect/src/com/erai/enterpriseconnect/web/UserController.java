/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0
 */
package com.erai.enterpriseconnect.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.core.util.DateUtil;
import com.erai.enterpriseconnect.core.util.EncrptBean;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.service.SecurityService;
import com.erai.enterpriseconnect.service.UserService;
import com.erai.enterpriseconnect.service.mail.SendEmailService;
import com.erai.enterpriseconnect.validator.ConfirmPasswordValidator;
import com.erai.enterpriseconnect.validator.UserValidator;

/**
 * User controller for user related activities
 * @author anand
 */
@Controller
@Component
public class UserController {
  private final Logger logger = LoggerFactory.getLogger(UserController.class);
  @Autowired
  private UserService userService;

  @Autowired
  private SecurityService securityService;

  @Autowired
  private UserValidator userValidator;

  @Autowired
  private MessageSource messageSource;

  @Autowired
  private SendEmailService mailMail;


  @Autowired
  private ConfirmPasswordValidator confirmPasswordValidator;

  @Value("${email.subject}")
  private String emailSubject;

  /**
   * Sample method in skeleton - remove after referring
   * @param model
   * @return
   */
  @RequestMapping(value = "/registration", method = RequestMethod.GET)
  public String registration(Model model) {
    model.addAttribute("userForm", new UserProfile());
    return "registration";
  }

  /**
   * Sample actions in skeleton - remove after referring
   * @param userForm
   * @param bindingResult
   * @param model
   * @return
   */
  @RequestMapping(value = "/registration", method = RequestMethod.POST)
  public String registration(@ModelAttribute("userForm") UserProfile userForm,
      BindingResult bindingResult, Model model) {
    userValidator.validate(userForm, bindingResult);
    if (bindingResult.hasErrors()) {
      return "registration";
    }
    userService.save(userForm);
    securityService.autologin(userForm.getEmail(),
        userForm.getPasswordConfirm());
    return "redirect:/welcome";
  }

  /**
   * Action for login
   * 
   * @param request
   * @param model
   * @param error
   * @param logout
   * @return login view
   */
  @RequestMapping(value = "/login", method = RequestMethod.GET)
  public String login(HttpServletRequest request, Model model, String error,
      String logout, String sessionTimeout) {
    logger.debug("Start login Action");
    logger.debug("Current user locale" + request.getLocale().getLanguage());
    logger.debug("Error" + error);
    model.addAttribute("locale", request.getLocale().getLanguage());
    if (error != null || request.getParameter("error") != null)
      model.addAttribute("error", "login.authentication.error");
    else if (logout != null || request.getParameter("logout") != null) {
      model.addAttribute("message", "login.logout");
    } else if (sessionTimeout != null
        || request.getParameter("sessionTimeout") != null) {
      model.addAttribute("error", "login.sessionTimeout");
    }
    logger.debug("End login Action");
    return "login";
  }

  /**
   * Action to display dashboard
   * @param model
   * @param request
   * @param response
   * @return dashboard view
   */
  @RequestMapping(value = { "/", "/dashboard" }, method = RequestMethod.GET)
  public String dashboard(Model model, HttpServletRequest request, HttpServletResponse response) {
    logger.debug("Start dashboard Action");
    String username = securityService.findLoggedInUsername();
    logger.debug("Logged in Name :" + username);
    UserProfile userProfile = userService.findByEmail(username);
    logger.debug("Locale Time :" + DateUtil.getLocaleTime(userProfile.getTimeZone()));
    HttpSession session = request.getSession();
    session.setAttribute("timezone", userProfile.getTimeZone());
    session.setAttribute("username", userProfile.getName());
    return "dashboard";
  }

  /**
   * Action to display Jimu Dashboard
   * @param model
   * @param request
   * @param response
   * @return dashboard view
   */
  @RequestMapping(value = "/invalidsession", method = RequestMethod.GET)
  public String checkSession(Model model, HttpServletRequest request,
      @CookieValue(value = "selLocale", defaultValue = "en") String selLocale,
      HttpServletResponse response) {
    logger.debug("Start checkSession Action");
    String loginPage = Constants.LOGIN;
    String login = "redirect:/" + loginPage + "?sessionTimeout";
    logger.debug("selLocale :" + selLocale);
    if (!StringUtils.isEmpty(selLocale)) {
      login = login + Constants.PARAM_SEP + Constants.LANGUAGE + Constants.EQUAL + selLocale;
    }
    return login;
  }

  /**
   * Action to display forget password page
   * @return forgot_password view
   */
  @RequestMapping(value = "/forgetPassword", method = RequestMethod.GET)
  public String showForgetPasswordPage() {
    logger.debug("Start showForgetPasswordPage");
    logger.debug("End showForgetPasswordPage");
    return "forgot_password";
  }

  /**
   * Action to send reset password link
   * @param model
   * @param email
   * @return
   */
  @RequestMapping(value = "/forgetPassword", method = RequestMethod.POST)
  public String forgetPassword(HttpServletRequest request,
      @RequestParam("email") String email, Model model) {
    logger.debug("Start forgetPassword");
    UserProfile user = userService.findByEmail(email);
    if (user != null) {
      logger.debug("user exist.");
      StringBuffer url = request.getRequestURL();
      String resetUrl = url.substring(0, url.lastIndexOf("/")) + "/showResetPasswordPage?key=" + EncrptBean.encrypt(email);
      EncrptBean.decrypt(EncrptBean.encrypt(email));
      mailMail.sendMail(email, resetUrl, emailSubject);
      model.addAttribute("Reset_Mail_Sent", "password.rest_url.sent");
      logger.debug("Password reset sent. url" + url);
      return "forgot_password";
    } else {
      logger.debug("User_Not_Exist invalid email id");
      model.addAttribute("User_Not_Exist", "forgetpassword.emailid.not.correct");
      return "forgot_password";
    }
  }

  /**
   * @param key
   * @param model
   * @return
   */
  @RequestMapping(value = "/showResetPasswordPage", method = RequestMethod.GET)
  public String showResetPasswordPage(@RequestParam("key") final String key, Model model) {
    logger.debug("Start showResetPasswordPage");
    UserProfile existUser = userService.findByEmail(EncrptBean.decrypt(key));
    if (existUser != null) {
      UserProfile user = new UserProfile();
      user.setEmail(existUser.getEmail());
      model.addAttribute("resetUser", user);
      logger.debug("correct key! User exist.");
      return "reset_password";
    } else {
      logger.error("worng key!!");
      return "error_page";
    }
  }
  
  /**
   * @param resetUser
   * @param bindingResult
   * @return
   */
  @RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
  public String resetPassword(@ModelAttribute("resetUser") UserProfile resetUser,
      BindingResult bindingResult, Model model) {
    confirmPasswordValidator.validate(resetUser, bindingResult);
    if (bindingResult.hasErrors()) {
      model.addAttribute("mismatch", "resetpassword.not.match");
      return "reset_password";
    }
    userService.changePassword(resetUser);
    model.addAttribute("password_reset", "password.reset");
    return "reset_password";
  }
}