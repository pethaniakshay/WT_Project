//checks whether the string is having numerics
function validate_number(input_number){
  var input_number = input_number.toString();
	if (!input_number.match(/^\d+$/))
  	{
  		return false;
  	}
  	return true;
}


//checks whether the string is having numerics and alphabet
function validate_alpha_numeric(input_string){
  if (!input_string.match(/^[0-9a-zA-Z]+$/))
    {
      return false;
    }
    return true;
}

function validate_alpha_numeric_with_space(input_string){
	if (!input_string.match(/^[a-zA-Z0-9\-\s]+$/))
    {
      return false;
    }
    return true;
}

function validate_alpha_numeric_with_space_dot(input_string){
	if (!input_string.match(/^[a-zA-Z0-9.\-\s]+$/))
    {
      return false;
    }
    return true;
}



//arg-1 - string, arg-2 minimum length the string should be , arg-3 maximum length the string should be
function validate_string_length(input_string,min,max){
 var str_length = input_string.length;
 console.log(str_length)
 if((str_length > max) || (str_length < min)){
    return false;
 }
 return true;
}


//arg-1 - string, arg-2 minimum length the alphanumeric should be , arg-3 maximum length the alphanumeric should be
function validate_alpha_numeric_for_length(input_string,min,max){
  if(validate_alpha_numeric(input_string)){
    if(validate_string_length(input_string,min,max)){
      return true;
    }
  }
  return false;
}


//it validates whether the input number's minimun digit 
//length and maximum digit length, 
//Even 0001 with min length of 3 will return false
function validate_number_for_count(input_number,min,max){
 if(validate_number(input_number)){
    if((input_number > max) || (input_number < min)){
      return false;
    }
  }
  return true 
}

//www.xxxxxxxxxxxxxx [or] http://xxxxxxxxxxxxxxxx [or] https://xxxxxxxxxxxxxxxxx
function validate_website(input_string){
  return /^(WWW\.|www\.|http:\/\/|https:\/\/)[^ ]+[\.]+[a-zA-Z]{2,}$/.test(input_string);
}



function validate_email(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function check_string_only_has_spaces(input_string)
{
	if (!input_string.replace(/\s/g, '').length) {
		return true;
	} 
	return false;
}

function validate_first_letter_alphanumeric(input_string){
	var first_letter = input_string[0];
	if (!first_letter.match(/^[0-9a-zA-Z]+$/))
  	{
  		return false;
  	}
  	return true;
}