var current_expanded_client = '';

function slide_down(div_id){
	if(current_expanded_client != ''){
		if(current_expanded_client == div_id){
			$('#'+div_id).toggle()
			 current_expanded_client = '';
		}
		else{
			$('#'+div_id).toggle()
			$('#'+current_expanded_client).toggle()
			current_expanded_client = div_id;
		}
		
	}
	else{
		$('#'+div_id).toggle()
		 current_expanded_client = div_id;
	}
	 
	 
}

$(document).ready(function() {
	 			
	          var all_country_elements = $('.selCountry');
	          
	          $(all_country_elements).each(function(){
	        	  var closest = $(this).next('.txtCountryID');
        		  sendAjaxRequestCountryWiseBank(this);
        		  closest.val($(this).val()); 
	          })
	 
        	  $(".selCountry").change(function(){
        		  var closest = $(this).next('.txtCountryID');
        		 sendAjaxRequestCountryWiseBank(this);
        		 closest.val($(this).val()); 
        	    }); 
        	  
        	  
        	  
        	  $(".selPaymentBank").change(function(){
        		  var closest = $(this).next('.txtBankID');
        		  closest.val($(this).val()); 
        	    });
        	 
        	  $(".selClientStatus").change(function(){
        		  var closest = $(this).next('.txtClientStatusId');
        		  closest.val($(this).val()); 
        	    });
        	  
   	    	$(".selUsers").change(function(){
   	    		 var closest = $(this).next('.txtUserID');
   	    		closest.val($(this).val());
  	    	});
   	    	
   	    	
   	    	$(document).click(function (event) { 
   	    		//alert($("#spanSuccessMsg"));
   	    		$("#spanSuccessMsg").html(" ");
   	    	});
   	    	$(document).click(function (event) { 
   	    		//alert($("#spanSuccessMsg"));
   	    		$("#spanErrorMsg").html(" ");
   	    	});
         });

function validate_submit(form_id){
	$("#"+form_id).each(function(){
	    var all_input_fields = $(this).find('input');
	    console.log(all_input_fields);
	    var total_elements_length = all_input_fields.length;
	    var total_errors = 0;
	    console.log(total_elements_length)
	    
	    $.each(all_input_fields, function (i, val) {
	    	var return_boolean;
	    	if($(val).attr('name') == 'zipCode'){
	    		return_boolean =  zipcode_validation(val,'selCountry')
	    	}
	    	else if($(val).attr('name') == 'telephoneNo'){
	    		return_boolean =  phonenumber_validation(val,'selCountry')
	    	}
	    	else
	    	{
	    		return_boolean = validate_client(val);
	    	}
	    	
	    	if(return_boolean == false){
	    		total_errors++;
	    	}
	    	if(total_elements_length-1 == i){
	    		if(total_errors > 0){
	    			return false;
	    		}
	    		else{
	    			
	    			$("#"+form_id+"-submit").trigger('click')
	    			//alert(form_id);
	    		}
	    	}
	    });
	});
	return false;

}

function validate_client(element){
	
	var element_type= $(element).attr('type');
	if(element_type == 'hidden'){
		return true;
	}
	
	
	 if(!($(element).is('select'))){
		 
		 if($(element).val().length == 0){
			 show_error(element,'cannot be empty');
			 return false;
		 }
		 
		 if(check_string_only_has_spaces($(element).val())){
			show_error(element,'only has space characters');
			return false;
		 }
		 
		 var str = $(element).val();
		 $(element).val(str.trim($(element).val()))
	 }

	 var element_name = $(element).attr('name');
	
	 if(element_name == 'website'){
		if(!validate_website($(element).val())){
			show_error(element,strings['invalid.website']);
			return false;
		}
		hide_error(element);
		return true;
	 }
	 else if(element_name == "address"){
		   if(!validate_first_letter_alphanumeric($(element).val())){
		    show_error(element,'First letter should be alphanumeric')
		    return false;
		   }
		   hide_error(element);
		   return true;
		  }
	 else if(element_name == 'email'){
		if(!validate_email($(element).val())){
			console.log('inside email error');
			show_error(element,'invalid email');
			return false;
		}
		hide_error(element);
		return true;
	 }
	 
	 
	 
	 
	 hide_error(element);
	return true;
}

function get_selected_country(element,country_select_box_id){
	console.log('inside');
	var form_near =  $(element).closest('form');
	var select_box_country_element = $(form_near).find('.'+country_select_box_id);
	var selected_country = $("option:selected", select_box_country_element).text()
	selected_country = selected_country.trim();
	
	return selected_country
}

//zip code
function zipcode_validation(zipcode_element,country_select_box_id){
	 
	 var selected_country = get_selected_country(zipcode_element,country_select_box_id)
	 
	 var zipcode = $(zipcode_element).val();
	 if(selected_country == ""){
	  show_error(zipcode_element,'Invalid input')
	  return false;
	 }
	 
	 else{
	  if(!validate_zipcode(zipcode,selected_country)){
		  show_error(zipcode_element,'Invalid '+selected_country+ ' zipcode')
		  return false;
	  }
	 }
	 hide_error(zipcode_element);
	 return true;
}



function phonenumber_validation(phonenumber_element,country_select_box_id){
	 
	 var selected_country = get_selected_country(phonenumber_element, country_select_box_id)
	 
	 var phonenumber = $(phonenumber_element).val();
	 if(selected_country == ""){
	  show_error(phonenumber_element,'Invalid input')
	  return false;
	 }
	 
	 else{
	  if(!validate_phone_number(phonenumber,selected_country)){
		  show_error(phonenumber_element,'Invalid '+selected_country+ ' telehphone format')
		  return false;
	  }
	 }
	 hide_error(phonenumber_element);
	 return true;
}



function show_error(element,error_statement){
	if(error_statement == undefined){
		error_statement = '';
	}
	var validation_message_element =  $(element).parent();
	var p_element = $(validation_message_element).children('p');
	$(p_element).html(error_statement)
	$(p_element).css('display','block');
	  
}

function hide_error(element){
	var validation_message_element =  $(element).parent();
	var p_element = $(validation_message_element).children('p');
	$(p_element).html('')
	$(p_element).css('display','none');
}

function edit_mode(id){
	 console.log("#"+id+'-edit-mode');
	 $("#"+id+'-edit-mode').removeClass('hidden');
	 $("#"+id).addClass('hidden');
	}

function view_mode(id){
 $("#"+id+'-edit-mode').addClass('hidden');
 $("#"+id).removeClass('hidden');
}

function toggle(id){
 if($("#"+id).hasClass('hidden')){
  $("#"+id).removeClass('hidden')
 }
 else{
  $("#"+id).addClass('hidden')
  }
}

function sendAjaxRequestCountryWiseBank(selObj){
	var form_near =  $(selObj).closest('form');
	var payment_bank = $(form_near).find('.selPaymentBank');
	var countryId=$(selObj).val();
	console.log(countryId);
	 $.get('selPayBankForCountry',{countryId:countryId},function(responseText){
		 console.log(responseText);
		 var conDetArr=responseText.split("@,C");
		 var bankOption="";
		 
		 for (var i = 0, len = conDetArr.length; i < len; i++) {
			 bankOption=bankOption+"<option value='"+conDetArr[i].split("#:@$#")[0]+"'>"+conDetArr[i].split("#:@$#")[1]+"</option>";
		 }
		 
		 
		 $(payment_bank).html(bankOption);
		 var closest = $(payment_bank).next('.txtBankID');
		 closest.val($(payment_bank).val());
		 sendAjaxRequestCountryWiseSalesPersons(selObj);
		 
	 });      		
}
 function sendAjaxRequestCountryWiseSalesPersons(selObj){
	 var countryId=$(selObj).val();
	 var form_near =  $(selObj).closest('form');
	 var sales_persons = $(form_near).find('.selUsers');
	 $.get('selSalesPersonForCountry',{countryId:countryId},function(responseText){
		 console.log(responseText);
		 var conDetArr=responseText.split("@,C");
		 var sales_person_option="";
		 
	 	 for (var i = 0, len = conDetArr.length; i < len; i++) {
	 		 sales_person_option = sales_person_option +"<option value='"+conDetArr[i].split("#:@$#")[0]+"'>"+conDetArr[i].split("#:@$#")[1]+"</option>";
	 	 }
		 
		 $(sales_persons).html(sales_person_option);
		 var closest = $(sales_persons).next('.txtUserID');
		 $(closest).val($(sales_persons).val());
		 //fill_TextBox();
	 });        	 
} 
function textChange(controll1){
	 //alert("textChange:"+controll1.value);
}
function validateFields(){
	 //alert("validateFields");
	 
	// return false;
}
function selBankList(){        	
	 sendAjaxRequestCountryWiseBank(document.getElementById("selCountry"));
	 //fill_TextBox();
}

function fill_TextBox(){ 
				
   	/*document.getElementById("txtCountryID").value=document.getElementById("selCountry").value;
   	document.getElementById("txtBankID").value=document.getElementById("selPaymentBank").value;
   	//alert("document.getElementById('txtBankID').value"+document.getElementById("txtBankID").value);
   	document.getElementById("txtClientStatusId").value=document.getElementById("selClientStatus").value;
   	document.getElementById("txtUserID").value=document.getElementById("selUsers").value;*/
}
