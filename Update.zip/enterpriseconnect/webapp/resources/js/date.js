function validate_date(date) //as per specification yyyy-mm-dd
{
    var matches = /^(\d{4})[-](\d{1,2})[-](\d{1,2})$/.exec(date);
    if (matches == null) return false;
    var m = matches[2] - 1;
    var y = matches[1];
    var d = matches[3];
    var composedDate = new Date(y, m, d);
    
    
    return composedDate.getDate() == d &&
            composedDate.getMonth() == m &&
            composedDate.getFullYear() == y;
}


//this function will be required while checking whether start date is smaller than end date, if the expectation fails returns false.
function compare_date(big_date,small_date){
    big_date = new Date(big_date);
    small_date = new Date(small_date);
    console.log(big_date + '--'+small_date)

    
    if(big_date > small_date){
        return true;
    }
    else if(big_date == small_date){
        return null
    }
    else {
        return false
    }
}


function format_yyyymmdd(date) ////YYYY/MM/DD or YYYY-MM-DD
{
    var matches = /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/.exec(date);
    if (matches == null) return false;
    var m = matches[2] - 1;
    var y = matches[1];
    var d = matches[3];
    var composedDate = new Date(y, m, d);
    
    
    return composedDate.getDate() == d &&
            composedDate.getMonth() == m &&
            composedDate.getFullYear() == y;
}


function format_mmddyyyy(date) //MM/DD/YYYY or MM-DD-YYYY
{
    var matches = /^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/.exec(date);
    if (matches == null) return false;
    var d = matches[2];
    var m = matches[1]-1;
    var y = matches[3];
    var composedDate = new Date(y, m, d);
    console.log(composedDate.getMonth())
    
    return composedDate.getDate() == d &&
            composedDate.getMonth() == m &&
            composedDate.getFullYear() == y;
}

function format_ddmmyyyy(date) //DD/MM/YYYY or DD-MM-YYYY
{
    var matches = /^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/.exec(date);
    if (matches == null) return false;
    var m = matches[2] - 1;
    var d = matches[1];
    var y = matches[3];
    var composedDate = new Date(y, m, d);
    console.log(composedDate.getMonth())
    
    return composedDate.getDate() == d &&
            composedDate.getMonth() == m &&
            composedDate.getFullYear() == y;
}

function formate_yyyyddmm(date) //YYYY/DD/MM or YYYY-DD-MM
{
    var matches = /^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/.exec(date);
    if (matches == null) return false;
    var d = matches[2];
    var y = matches[1];
    var m = matches[3]-1;
    var composedDate = new Date(y, m, d);
    console.log(composedDate.getMonth())
    
    return composedDate.getDate() == d &&
            composedDate.getMonth() == m &&
            composedDate.getFullYear() == y;
}


function format_yyyymmdd(date) ////YYYY/MM/DD or YYYY-MM-DD
{
    var matches = /^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})$/.exec(date);
    if (matches == null) return false;
    var m = matches[2] - 1;
    var y = matches[1];
    var d = matches[3];
    var composedDate = new Date(y, m, d);
    console.log(composedDate.getMonth())
    
    return composedDate.getDate() == d &&
            composedDate.getMonth() == m &&
            composedDate.getFullYear() == y;
}

//if one of date format is true it will return true
var validate_date_all_format = function(date_input){
  if(format_mmddyyyy(date_input))  {
      return true;
  }
  if(format_ddmmyyyy(date_input))  {
      return true;
  }
  if(format_yyyymmdd(date_input))  {
      return true;
  }
  if(formate_yyyyddmm(date_input)) {
      return true;
  }

}