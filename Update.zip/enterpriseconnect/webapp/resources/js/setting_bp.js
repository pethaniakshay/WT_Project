//On the page loading time show all bank list, currency exchange rate list and country list. 
$( window ).load = get_all_bank_list();


function get_all_bank_list(){
	var url = "/enterpriseconnect/bank_profile_show/";
	 var data = {}
    data["query"] = "abc";
	 var result_data;
	 var bankDetailElement = $("#bank_detail");
	 var currencyExchangeElement = $("#currency-exchange-rate");
	 var currencyExchangeEditElement = $("#currency-exchange-rate-edit-mode");
	 var country_element = $("#list-country");
	 var accountType_element = $("#list-account-type");
	 var financial_year_element = $("#financial-year");
	 var append_string = "";
	$.ajax({
		type : "GET",
       url : url,
       data : data,
       timeout : 100000,
       success : function(data) {
         result_data = data;
         
         bankList = result_data.bankList;
         countryList= result_data.countryList;
         financialYearList= result_data.financialYearList;
         accountTypeList= result_data.accountTypeList;
         currencyExchageList= result_data.currencyExchangeList;
         console.log(countryList);
//         append_string = "<option value='' selected disabled></option>";
         for(i = 0;i < countryList.length;i++){
       	  append_string = append_string + "<option value="+countryList[i].country_id+">"+countryList[i].country_name+"</option>";
         }
         $(country_element).html(append_string);
         
         append_string = "";
         for(i = 0;i < financialYearList.length;i++){
       	  append_string = append_string + "<option value="+financialYearList[i].financial_year_id+">"+financialYearList[i].financial_year+"</option>";
         }
         $(financial_year_element).html(append_string);
         
         append_string = "";
         for(i = 0;i < accountTypeList.length;i++){
       	  append_string = append_string + "<option value="+accountTypeList[i].account_id+">"+accountTypeList[i].account_type+"</option>";
         }
         $(accountType_element).html(append_string);
         
         append_string = "";
         for(i = 0;i < bankList.length;i++){
       	  append_string = append_string 
       	  + "<tr><td><a onclick=\"view_mode('client-detail-"+i+"');slide_down('client-profile-"+i+"')\" ><i class='fa fa-caret-square-o-up caret-icon'></i>"+bankList[i].bank_name
       	  +"</a></td><td>" +bankList[i].branch_name
       	  +"</td><td>" +bankList[i].account_type
       	  +"</td><td>" +bankList[i].account_no
       	  +"</td><td>" +bankList[i].account_name
       	  +"</td><td>" +bankList[i].country_name
       	  +"</td></tr><tr style='display:none' id='client-profile-"+i+"' ><td colspan='6'  >"
             +"<div>"
             +"<form action='siva.html' id='client-form-"+i+"' method='post' >"
             +"<div class='row padding-l-15'>"
             +   "<div class='col-md-12'>"
             +      "<div class='table-responsive'>"
             +         "<table id='client-detail-"+i+"' class='table setting-tbl'>"
             +            "<tbody>"
             +					"<tr>"
             +						"<td  class='col-md-2'>Bank Name</td>"
             +						"<td class='col-md-4'>"+bankList[i].bank_name+"</td>"
             +						"<td class='col-md-2'>Country</td>"
             +						"<td class='col-md-4'>"+bankList[i].country_name+"</td>"
             +					"</tr>"
             +					"<tr>"
             +						"<td class='col-md-2'>Branch Name</td>"
             +						"<td class='col-md-4'>"+bankList[i].branch_name+"</td>"
             +						"<td class='col-md-2'>SWIFT Code</td>"
             +						"<td class='col-md-4'>"+bankList[i].swift_code+"</td>"
             +					"</tr>"
             +					"<tr>"
             +						"<td class='col-md-2'>Account Type</td>"
             +						"<td class='col-md-4'>"+bankList[i].account_type+"</td>"
             +						"<td class='col-md-2'>Account No</td>"
             +						"<td class='col-md-4'>"+bankList[i].account_no+"</td>"
             +					"</tr>"
             +					"<tr>"
             +						"<td class='col-md-2'>Account Name</td>"
             +						"<td class='col-md-4'>"+bankList[i].account_name+"</td>"
             +					"</tr>"
             +					"<tr>"
             +						"<td class='col-md-2'>Bank Address & Tel</td>"
             +						"<td class='col-md-4'>"+bankList[i].address+"</td>"
             +					"</tr>"
             +           "</tbody>"
             +         "</table>"
             +         "<table  id='client-detail-"+i+"-edit-mode' class='table setting-tbl hidden'>"
             +            "<tbody>"
             +					"<tr>"
             +						"<td class='col-md-2'>Bank Name</td>"
             +						"<td class='col-md-4'><input class='bank_name'  name='bank_name' onfocusout='validate_bank(this)' type='text' value='"+bankList[i].bank_name+"'/><p style='display: none' class='help-block'><i class='fa fa-info-circle'  ></i>Invalid Input</p></td>"
             +						"<td class='col-md-2'>Country</td>"
             +						"<td class='col-md-4'><select class='country country-select' name='country'  ><option>"+bankList[i].country_name+"</option></select><p style='display: none' class='help-block'><i class='fa fa-info-circle'  ></i>Invalid Input</p></td>"
             +					"</tr>"
             +					"<tr>"
             +						"<td class='col-md-2'>Branch Name</td>"
             +						"<td class='col-md-4'><input class='branch_name' name='branch_name' type='text' onfocusout='validate_bank(this)' value='"+bankList[i].branch_name+"'/></td>"
             +						"<td class='col-md-2'>SWIFT Code</td>"
             +						"<td class='col-md-4'><input class='swift_code' name='swift_code' type='text' onfocusout='validate_bank(this)' value='"+bankList[i].swift_code+"'/><p style='display: none' class='help-block'><i class='fa fa-info-circle'  ></i>Invalid Input</p></td>"
             +						"<input  type='hidden' class='bank_id' value='" +bankList[i].bank_id +"'/>"
             +					"</tr>"
             +					"<tr>"
             +						"<td class='col-md-2'>Account Type</td>"
             +						"<td class='col-md-4'><select class='account_type account-type-select' name='account_type' onfocusout='validate_bank(this)'  ><option>"+bankList[i].account_type+"</option></select></td>"
             +						"<td class='col-md-2'>Account No</td>"
             +						"<td class='col-md-4'><input class='account_no' name='account_no' onfocusout='validate_bank(this)' type='text' value='"+bankList[i].account_no+"'/><p style='display: none' class='help-block'><i class='fa fa-info-circle'  ></i>Invalid Input</p></td>"
             +					"</tr>"
             +					"<tr>"
             +						"<td class='col-md-2'>Account Name</td>"
             +						"<td class='col-md-4'><input class='account_name' name='account_name'  onfocusout='validate_bank(this)' type='text' value='"+bankList[i].account_name+"'/><p style='display: none' class='help-block'><i class='fa fa-info-circle'  ></i>Invalid Input</p></td>"
             +					"</tr>"
             +					"<tr>"
             +						"<td class='col-md-2'>Bank Address & Tel</td>"
             +						"<td class='col-md-4'><input class='bank_address' name='bank_address' onfocusout='validate_bank(this)' type='text' value='"+bankList[i].address+"'/><p style='display: none' class='help-block'><i class='fa fa-info-circle'  ></i>Invalid Input</p></td>"
             +					"</tr>"
             +           "</tbody>"
             +         "</table>"
             +      "</div>"
             +   "</div>"
             + "</div>"
             + "<div class='row padding-l-15'>"
             +   "<div class='col-md-12'>"
             +      "<button type='reset' onclick=\"view_mode('client-detail-"+i+"')\" class='btn btn-primary btn-responsive pull-right'>Cancel</button>"
             +      "<button type='button' class='btn btn-primary btn-responsive pull-right' onclick=\"update_bank('client-form-"+i+"')\">Save</button>"
             +      "<button type='button' onclick=\"edit_mode('client-detail-"+i+"')\" class='btn btn-primary btn-responsive pull-right'>Edit</button>"
             +  "</div>"
             + "</div>"
             +"</form>"
             +	"</div>"
             +"</td></tr>"
      
         }
         $(bankDetailElement).html(append_string);
         append_string = "";
         for(i = 0;i < currencyExchageList.length;i++){
       	  append_string = append_string 
       	  + "<tr><td>"+currencyExchageList[i].currency_exchange_year
       	  +"</td><td>" +currencyExchageList[i].usd
       	  +"</td><td>" +currencyExchageList[i].jpy
       	  +"</td><td>" +currencyExchageList[i].inr;
       	  +"</td></tr>";
   	   	  +"<tr>"
   	   	     }
         $(currencyExchangeElement).html(append_string);
         
         
         var all_country_option = $(country_element).find('option')
            
         var all_list_country = $('.country-select')
        
         console.log('siva')
         all_list_country.each(function(){
       	  var single_edit = $(this).text();
       	  var single_edit_element = $(this);
       	  all_country_option.each(function(){
       		  if($(this).text() != single_edit){
       			  var option_country = "<option value='"+$(this).val()+"' >"+$(this).text()+"</option>";
       			  $(single_edit_element).append(option_country)
       		  }
       		  else{
       			  console.log($(':selected',single_edit_element).val($(this).val()))
       			  
       		  }
             })
         })
         
         
         var all_account_option = $(accountType_element).find('option')
            
         var all_list_account = $('.account-type-select')
         
         console.log()
         
         all_list_account.each(function(){
       	  var single_edit = $(this).text();
       	  var single_edit_element = $(this);
       	  all_account_option.each(function(){
       		  if($(this).text() != single_edit){
       			  var option_account = "<option value='"+$(this).val()+"' >"+$(this).text()+"</option>";
       			  $(single_edit_element).append(option_account)
       		  }
       		  else{
       			  console.log($(':selected',single_edit_element).val($(this).val()))
       		  }
             })
         })
         
         
         
         append_string = "";
         for(i = 0;i < currencyExchageList.length;i++){
       	  append_string = append_string 
       	  + "<tr><td class='year' >"+currencyExchageList[i].currency_exchange_year
       	  +"</td><td><input type='number' onfocusout='validate(this)' class='usd' value='" +currencyExchageList[i].usd +"' />"
       	  +"<p style='display: none' class='help-block'><i class=fa fa-info-circle'  ></i>Invalid Input</p></td><td><input onfocusout='validate(this)' type='number' class='jpy' value='" +currencyExchageList[i].jpy +"' />"
       	  +"<p style='display: none' class='help-block'><i class=fa fa-info-circle'  ></i>Invalid Input</p></td><td><input onfocusout='validate(this)' type='number' class='inr' value='" +currencyExchageList[i].inr +"' /><input  type='hidden' class='currency-id' value='" +currencyExchageList[i].currency_exchange_id +"' />"
       	  +"<p style='display: none' class='help-block'><i class=fa fa-info-circle'  ></i>Invalid Input</p></td>"
       	  
         }
         $(currencyExchangeEditElement).html(append_string);
         
       },
	});
}





//List of all currency exchange after adding
function get_currency_exchange_list(){
	var url = "/enterpriseconnect/bank_profile_show/";
	var data = {}
	data["query"] = "abc";
	var result_data;
	var currencyExchangeElement = $("#currency-exchange-rate");
	var currencyExchangeEditElement = $("#currency-exchange-rate-edit-mode");
	var append_string = "";
	$.ajax({
		type : "GET",
	   url : url,
	   data : data,
	   timeout : 100000,
	   success : function(data) {
	     result_data = data;
	     
	     currencyExchageList= result_data.currencyExchangeList;
	     append_string = "";
	     for(i = 0;i < currencyExchageList.length;i++){
	   	  append_string = append_string 
	   	  + "<tr><td>"+currencyExchageList[i].currency_exchange_year
	   	  +"</td><td>" +currencyExchageList[i].usd
	   	  +"</td><td>" +currencyExchageList[i].jpy
	   	  +"</td><td>" +currencyExchageList[i].inr;
	   	  
	   	  
	     }
	     $(currencyExchangeElement).html(append_string);
	     
	     append_string = "";
	     for(i = 0;i < currencyExchageList.length;i++){
	   	  append_string = append_string 
	   	  + "<tr><td class='year' >"+currencyExchageList[i].currency_exchange_year
	   	  +"</td><td><input type='number' class='usd' value='" +currencyExchageList[i].usd +"' />"
	   	  +"</td><td><input type='number' class='jpy' value='" +currencyExchageList[i].jpy +"' />"
	   	  +"</td><td><input type='number' class='inr' value='" +currencyExchageList[i].inr +"' />"
	   	  +"</td><td><input type='hidden' class='currency-id' value='" +currencyExchageList[i].currency_exchange_id +"' />"
	   	  
	     }
	     $(currencyExchangeEditElement).html(append_string);
	     
	   },
	});
	
}



function edit_mode(id){
	console.log("#"+id+'-edit-mode');
	$("#"+id+'-edit-mode').removeClass('hidden');
	$("#"+id).addClass('hidden');
}

function view_mode(id){
	$("#"+id+'-edit-mode').addClass('hidden');
	$("#"+id).removeClass('hidden');
}

function toggle(id){
	if($("#"+id).hasClass('hidden')){
		$("#"+id).removeClass('hidden')
	}
	else{
		$("#"+id).addClass('hidden')
	}
}

function save_new_currency(){
	
	var data = [ {
		"year" : $("#new-year").val(),
		"usd" : $("#new-usd").val(),
		"inr" : $("#new-inr").val(),
		"jpy" : $("#new-jpy").val()
	} ]
	console.log(data)
	var url = "/enterpriseconnect/new_currency_Add/";
	var messageProperty = $("#add-new-currency-message");
	$.ajax({
		url : url,
		data : JSON.stringify(data),
		dataType : "json",
		method : "POST",
		headers : {
			"Content-Type" : "application/json"
		},
		success : function(success_data) {
			$(messageProperty).html("saved successfully");
			
		}
	});
	
	
}









//Add the new bank
function add_bank() {
	var bank_name = $("#bank_name").val();
	var country = $("#list-country").val();
	var branch_name = $("#branch_name").val();
	var swift_code = $("#swift_code").val();
	var account_type = $("#list-account-type").val();
	var account_no = $("#account_no").val();
	var account_name = $("#account_name").val();
	var bank_address = $("#bank_address").val();
	
	
	if(!validate_bank($("#bank_name"))){
		return;
	}
	else if(!validate_bank($("#branch_name"))){
		return;
	}
	else if(!validate_bank($("#swift_code"))){
		return;
	}
	else if(!validate_bank($("#account_no"))){
		return;
	}
	else if(!validate_bank($("#account_name"))){
		return;
	}
	else if(!validate_bank($("#bank_address"))){
		return;
	}
	else{
		
	}
	
	var data = [ {
		"bank_name" : bank_name,
		"country" : country,
		"branch_name" : branch_name,
		"swift_code" : swift_code,
		"account_type" : account_type,
		"account_no" : account_no,
		"account_name" : account_name,
		"bank_address" : bank_address
	} ]
	console.log(data);
	var url = "/enterpriseconnect/bank_profile_add/";
	var messageProperty = $("#add-new-bank-message");
	$.ajax({
		url : url,
		data : JSON.stringify(data),
		dataType : "json",
		method : "POST",
		headers : {
			"Content-Type" : "application/json"
		},
		success : function(data) {
			get_all_bank_list()
			//$(messageProperty).html("saved successfully");
		}
	/*}).
	error(function(data) {
		$(messageProperty).html("Dublicate data");*/
	});
	
	
}










//Update the  bank
function update_bank(form_id) {
	
	form_id = '#'+form_id;

	var bank_name = $(form_id).find(".bank_name").val();
	var branch_name = $(form_id).find(".branch_name").val();
	var swift_code = $(form_id).find(".swift_code").val();
	var account_type = $(form_id).find(".account_type").val();
	var account_no = $(form_id).find(".account_no").val();
	var account_name = $(form_id).find(".account_name").val();
	var bank_address = $(form_id).find(".bank_address").val();
	var country = $(form_id).find(".country").val();
	var bank_id = $(form_id).find(".bank_id").val();
	

	
	
	if(!$(form_id).find(".bank_name")){
		return;
	}
	else if(!$(form_id).find(".branch_name")){
		return;
	}
	else if(!$(form_id).find(".swift_code")){
		return;
	}
	else if(!$(form_id).find(".account_type")){
		return;
	}
	else if(!$(form_id).find(".account_no")){
		return;
	}
	else if(!$(form_id).find(".bank_address")){
		return;
	}
	else{
		
	}
	
	var data = [ {
		"bank_name" : bank_name,
		"country" : country,
		"branch_name" : branch_name,
		"swift_code" : swift_code,
		"account_type" : account_type,
		"account_no" : account_no,
		"account_name" : account_name,
		"bank_address" : bank_address,
		"bank_id":bank_id 
	} ]

	var url = "/enterpriseconnect/bank_profile_update/";
	var messageProperty = $("#add-new-bank-message");
	$.ajax({
		url : url,
		data : JSON.stringify(data),
		dataType : "json",
		method : "POST",
		headers : {
			"Content-Type" : "application/json"
		},
		success : function(data) {
			get_all_bank_list()
			$(messageProperty).html("updated successfully");
		}
	/*}).
	error(function(data) {
		$(messageProperty).html("Dublicate data");*/
	});
	
	
}







//Clear the field for add bank function
function clearField() {
	var messageProperty = $("#add-new-bank-message");
	$(messageProperty).html("");
	document.getElementById("bank_name").value=null;
	document.getElementById("list-country").value=null;
	document.getElementById("branch_name").value=null;
	document.getElementById("swift_code").value=null;
	document.getElementById("account_type").value=null;
	document.getElementById("account_no").value=null;
	document.getElementById("account_name").value=null;
	document.getElementById("bank_address").value=null;
}











function send_edited_currency(){
	console.log("edited----------");
	var currency_data = [] 
	var messageProperty = $("#add-new-bank-message");
	var currencyExchangeEditElement = $("#currency-exchange-rate-edit-mode");
	var count = 0;
	$("#currency-exchange-rate-edit-mode .year").each(function(){
		currency_data[currency_data.length] =   {
			    "year":"",
			    "usd":0,
			    "jpy":0,
			    "inr":0,
			    "currency-id":0
			  };
	});
	
	$("#currency-exchange-rate-edit-mode .year").each(function(){
		currency_data[count].year = $(this).html();   
		count++;
	});
	
	count = 0;
	$("#currency-exchange-rate-edit-mode .usd").each(function(){
			currency_data[count].usd= $(this).val();
			count++;
		});
	count = 0;
	$("#currency-exchange-rate-edit-mode .inr").each(function(){		
		currency_data[count].inr= $(this).val();
		count++;
	});
	count = 0;
	$("#currency-exchange-rate-edit-mode .jpy").each(function(){
		currency_data[count].jpy = $(this).val();   
		count++;
	});
	count = 0;
	$("#currency-exchange-rate-edit-mode .currency-id").each(function(){
		currency_data[count].currency_exchange_id = $(this).val();   
		count++;
	});
	
	
	console.log(currency_data);
	
	
	var url = "/enterpriseconnect/edit_currency_exchange_edit/";
	$.ajax({
		url : url,
		data : JSON.stringify(currency_data),
		dataType : "json",
		method : "POST",
		headers : {
			"Content-Type" : "application/json"
		},
		success : function(success_data) {
			
			get_currency_exchange_list();
			$(messageProperty).html("saved successfully");
			view_mode('currency-exchange-rate');
		}
	});
	
		
}




//Add the new currency
function save_new_currency() {
	var financial_year = $("#financial-year :selected")
	financial_year = $(financial_year).val();
	var add_usd = $("#add-usd").val();
	var add_jpy = $("#add-jpy").val();
	var add_inr = $("#add-inr").val();
	console.log(add_usd);
	console.log(add_jpy);
	console.log(add_inr);
	
	var data = [ {
		"financial_year" : financial_year,
		"add_usd" : add_usd,
		"add_jpy" : add_jpy,
		"add_inr" : add_inr
	} ]

	var url = "/enterpriseconnect/currency_exchange_add/";
	var messageProperty = $("#add-new-bank-message");
	$.ajax({
		url : url,
		data : JSON.stringify(data),
		dataType : "json",
		method : "POST",
		headers : {
			"Content-Type" : "application/json"
		},
		success : function(success_data) {
			$(messageProperty).html("saved successfully");
			get_currency_exchange_list();
			
		}
	});
	
}

var current_expanded_client = '';

function slide_down(div_id){
	console.log(div_id);
	if(current_expanded_client != ''){
		if(current_expanded_client == div_id){
			$('#'+div_id).toggle()
			 current_expanded_client = '';
		}
		else{
			$('#'+div_id).toggle()
			$('#'+current_expanded_client).toggle()
			current_expanded_client = div_id;
		}
		
	}
	else{
		$('#'+div_id).toggle()
		 current_expanded_client = div_id;
	}
	 
	 
}
//Validation For Bank Profile

function edit_mode(id){
	 console.log("#"+id+'-edit-mode');
	 $("#"+id+'-edit-mode').removeClass('hidden');
	 $("#"+id).addClass('hidden');
	}

function view_mode(id){
$("#"+id+'-edit-mode').addClass('hidden');
$("#"+id).removeClass('hidden');
}

