

function validate_bank(element){
	
	 
	 if(!$(element).is('select')){
		 if(check_string_only_has_spaces($(element).val())){
			show_error(element);
			return false;
		 }
		 
		 if($(element).val().length == 0){
			 show_error(element,'cannot be empty');
			 return false;
		 }
		 
	 }
	 
	 
	 
	 
	 var element_type = $(element).attr('name');
	
	 if(element_type == 'bank_name'){
		if(!validate_alpha_numeric_with_space($(element).val())){
			show_error(element);
			return false;
		}
		hide_error(element);
		return true;
	 }
	
	 else if(element_type == 'branch_name'){
		if(!validate_alpha_numeric_with_space_dot($(element).val())){
			show_error(element);
			return false;
		}
		hide_error(element);
		return true;
	 }
	
	else if(element_type == 'account_name'){
		if(!validate_alpha_numeric_with_space_dot($(element).val())){
			show_error(element);
			return false;
		}
		hide_error(element);
		return true;
	 }
	 
	else if(element_type == 'bank_address'){
		if(!validate_alpha_numeric_with_space_dot($(element).val())){
			show_error(element);
			return false;
		}
		hide_error(element);
		return true;
	 }
	
	//Bank Address and telephone number can have any characters 
	 
	else if(element_type == 'country'){
		if($(element).val() == null){
			  show_error(element)
			  return false;	
		}
		hide_error(element);
		return true;
	}
	 
	else if(element_type == 'swift_code'){
		if(!validate_alpha_numeric_for_length($(element).val(),0,20)){
			show_error(element);
			return false;
		}
		hide_error(element);
		return true;
	}
	 
	else if(element_type == 'account_no'){
		if(!validate_alpha_numeric($(element).val())){
			show_error(element);
			return false;
		}
		hide_error(element);
		return true;
	} 
	else{
		hide_error(element);
		return true;
	}
}



function show_error(element){
	var validation_message_element =  $(element).parent();
	var p_element = $(validation_message_element).children('p');
	$(p_element).css('display','block');
	  
}

function hide_error(element){
	var validation_message_element =  $(element).parent();
	var p_element = $(validation_message_element).children('p');
	$(p_element).css('display','none');
}

function edit_mode(id){
	 console.log("#"+id+'-edit-mode');
	 $("#"+id+'-edit-mode').removeClass('hidden');
	 $("#"+id).addClass('hidden');
	}

function view_mode(id){
$("#"+id+'-edit-mode').addClass('hidden');
$("#"+id).removeClass('hidden');
}

function toggle(id){
if($("#"+id).hasClass('hidden')){
 $("#"+id).removeClass('hidden')
}
else{
 $("#"+id).addClass('hidden')
 }
}

