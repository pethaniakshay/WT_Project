function validate_zipcode(zipcode,country){
	if(country == 'INDIA'){
		//xxxxxx   <here x must be a number >
		var matches = /^[1-9][0-9]{5}$/.exec(zipcode);
	    if (matches == null) return false;
	    return true;	
	}
	if(country == 'USA'){
		//xxxxx   <here x must be a number >
		var matches = /^[0-9][0-9]{4}$/.exec(zipcode);
	    if (matches == null) return false;
	    return true;
	}
	if(country == 'JAPAN'){
		//xxx-xxxx   <here x must be a number >
		var matches = /^([0-9]){3}[-]([0-9]){4}$/.exec(zipcode);
	    if (matches == null) return false;
	    return true;	
	}
}

